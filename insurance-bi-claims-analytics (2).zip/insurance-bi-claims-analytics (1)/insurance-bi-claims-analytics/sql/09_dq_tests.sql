-- =====================================================================
-- 09_dq_tests.sql   Post-load data-quality tests (the "quality gate").
-- Every test returns the number of offending rows. Results are stored in
-- etl.dq_test_result. If any BLOCKING test fails the procedure raises,
-- the orchestrator marks the run FAILED and Power BI should not refresh.
-- =====================================================================
CREATE TABLE IF NOT EXISTS etl.dq_test_result (
    run_id       BIGINT NOT NULL REFERENCES etl.job_run(run_id),
    test_name    VARCHAR(100) NOT NULL,
    blocking     BOOLEAN NOT NULL,
    failed_rows  INT NOT NULL,
    passed       BOOLEAN NOT NULL,
    tested_at    TIMESTAMPTZ NOT NULL DEFAULT clock_timestamp(),
    PRIMARY KEY (run_id, test_name)
);

CREATE OR REPLACE PROCEDURE etl.run_dq_tests(p_run_id BIGINT, p_max_reject_pct NUMERIC DEFAULT 5)
LANGUAGE plpgsql AS $$
DECLARE
    v_started TIMESTAMPTZ := clock_timestamp();
    v_blocking_failures INT;
BEGIN
    INSERT INTO etl.dq_test_result(run_id, test_name, blocking, failed_rows, passed)
    SELECT p_run_id, t.test_name, t.blocking, t.failed_rows, t.failed_rows = 0
    FROM (
        -- 1. Reconciliation: every staged row is accounted for in every step
        SELECT 'reconciliation_rows_accounted_for' AS test_name, TRUE AS blocking,
               COUNT(*)::INT AS failed_rows
        FROM etl.step_log
        WHERE run_id = p_run_id AND step_name LIKE 'load_%'
          AND rows_read <> rows_duplicate + rows_rejected + rows_inserted + rows_updated + rows_unchanged

        UNION ALL
        -- 2. Reconciliation of money: premium in DW = valid premium in staging
        SELECT 'premium_amount_reconciles_with_source', TRUE,
               CASE WHEN (SELECT COALESCE(SUM(amount), 0) FROM etl.v_premium_validated WHERE reject_reason IS NULL)
                       = (SELECT COALESCE(SUM(f.amount), 0) FROM dw.fact_premium_payment f
                          JOIN stg.premium_payments s ON s.payment_id = f.source_payment_id)
                    THEN 0 ELSE 1 END

        UNION ALL
        -- 3. Business rule: a claim must fall inside its policy coverage period
        SELECT 'claim_within_policy_coverage', TRUE, COUNT(*)::INT
        FROM dw.fact_claim f
        JOIN dw.dim_policy p ON p.policy_key = f.policy_key
        JOIN dw.dim_date d   ON d.date_key   = f.claim_date_key
        WHERE d.full_date NOT BETWEEN p.start_date AND p.end_date

        UNION ALL
        -- 4. Denormalised keys on the fact must agree with the policy dimension
        SELECT 'claim_keys_consistent_with_policy', TRUE, COUNT(*)::INT
        FROM dw.fact_claim f
        JOIN dw.dim_policy p ON p.policy_key = f.policy_key
        WHERE f.customer_key <> p.customer_key OR f.product_key <> p.product_key

        UNION ALL
        -- 5. Quality gate: rejection rate per step below threshold
        SELECT 'reject_rate_below_' || p_max_reject_pct || '_pct', TRUE, COUNT(*)::INT
        FROM etl.step_log
        WHERE run_id = p_run_id AND step_name LIKE 'load_%' AND rows_read > 0
          AND 100.0 * rows_rejected / rows_read > p_max_reject_pct

        UNION ALL
        -- 6. Non-blocking: PAID claims should have a payout (flag for business review)
        SELECT 'paid_claims_have_payout', FALSE, COUNT(*)::INT
        FROM dw.fact_claim WHERE claim_status = 'PAID' AND paid_amount = 0

        UNION ALL
        -- 7. Non-blocking: share of customers with Unknown region should stay small
        SELECT 'unknown_region_under_10_pct', FALSE,
               CASE WHEN 100.0 * COUNT(*) FILTER (WHERE region = 'Unknown') / NULLIF(COUNT(*), 0) > 10
                    THEN 1 ELSE 0 END
        FROM dw.dim_customer
    ) t;

    SELECT COUNT(*) INTO v_blocking_failures
    FROM etl.dq_test_result WHERE run_id = p_run_id AND blocking AND NOT passed;

    CALL etl.log_step(p_run_id, 'dq_tests', v_started, 0);
    -- persist results BEFORE raising, otherwise the exception would roll them back
    COMMIT;

    IF v_blocking_failures > 0 THEN
        RAISE EXCEPTION 'Data quality gate failed: % blocking test(s) failed for run %',
                        v_blocking_failures, p_run_id;
    END IF;
END;
$$;
