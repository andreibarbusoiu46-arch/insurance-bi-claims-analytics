-- =====================================================================
-- 06_load_procedures.sql
-- Pattern used by every procedure (the same pattern a Talend job uses):
--   read validated view -> log ERROR rows to etl.data_quality_issue
--   -> log WARNING rows (loaded with correction) -> log duplicates
--   -> UPSERT valid, de-duplicated rows -> write counts to etl.step_log
--
-- Idempotency: INSERT ... ON CONFLICT (business key) DO UPDATE ... WHERE
-- the row actually changed. Running the pipeline twice on the same data
-- gives the same warehouse state; the 2nd run reports 0 inserts/updates.
-- The (xmax = 0) trick in RETURNING tells an INSERT apart from an UPDATE.
-- =====================================================================

-- ---------------------------------------------------------------- dim_customer (SCD Type 1)
CREATE OR REPLACE PROCEDURE etl.load_dim_customer(p_run_id BIGINT)
LANGUAGE plpgsql AS $$
DECLARE
    v_started TIMESTAMPTZ := clock_timestamp();
    v_read INT; v_dup INT; v_rej INT; v_valid INT; v_ins INT; v_upd INT;
BEGIN
    SELECT count(*),
           count(*) FILTER (WHERE reject_reason IS NOT NULL),
           count(*) FILTER (WHERE dup_rank > 1),
           count(*) FILTER (WHERE dup_rank = 1)
      INTO v_read, v_rej, v_dup, v_valid
      FROM etl.v_customer_validated;

    -- rejected rows
    INSERT INTO etl.data_quality_issue(run_id, entity, record_key, rule_code, severity, details, raw_record)
    SELECT p_run_id, 'customer', customer_id, reject_reason, 'ERROR', 'Row rejected', raw_record
      FROM etl.v_customer_validated WHERE reject_reason IS NOT NULL;

    -- superseded duplicates
    INSERT INTO etl.data_quality_issue(run_id, entity, record_key, rule_code, severity, details, raw_record)
    SELECT p_run_id, 'customer', customer_id, 'DUPLICATE_SUPERSEDED', 'WARNING',
           'Older version dropped; newest last_updated kept', raw_record
      FROM etl.v_customer_validated WHERE dup_rank > 1;

    -- rows loaded with a correction (one row per failed soft rule)
    INSERT INTO etl.data_quality_issue(run_id, entity, record_key, rule_code, severity, details, raw_record)
    SELECT p_run_id, 'customer', v.customer_id, w.rule_code, 'WARNING', w.details, v.raw_record
      FROM etl.v_customer_validated v
     CROSS JOIN LATERAL (VALUES
        ('INVALID_BIRTH_DATE', v.birth_date_raw IS NOT NULL AND v.birth_date IS NULL,
                               'birth_date set to NULL, raw value: ' || COALESCE(v.birth_date_raw, '')),
        ('MISSING_EMAIL',      v.email_raw IS NULL,                         'email left NULL'),
        ('INVALID_EMAIL',      v.email_raw IS NOT NULL AND v.email IS NULL, 'email set to NULL'),
        ('MISSING_REGION',     v.region_raw IS NULL,                        'region defaulted to Unknown'),
        ('INVALID_SEGMENT',    v.segment = 'Unknown',                       'segment defaulted to Unknown')
     ) AS w(rule_code, failed, details)
     WHERE v.dup_rank = 1 AND w.failed;

    WITH upserted AS (
        INSERT INTO dw.dim_customer AS t
               (customer_id, first_name, last_name, email, birth_date, region, segment, source_updated_at)
        SELECT customer_id, first_name, last_name, email, birth_date, region, segment, last_updated
          FROM etl.v_customer_validated
         WHERE dup_rank = 1
        ON CONFLICT (customer_id) DO UPDATE
           SET first_name = EXCLUDED.first_name, last_name = EXCLUDED.last_name,
               email = EXCLUDED.email, birth_date = EXCLUDED.birth_date,
               region = EXCLUDED.region, segment = EXCLUDED.segment,
               source_updated_at = EXCLUDED.source_updated_at, dw_updated_at = now()
         WHERE (t.first_name, t.last_name, t.email, t.birth_date, t.region, t.segment)
               IS DISTINCT FROM
               (EXCLUDED.first_name, EXCLUDED.last_name, EXCLUDED.email,
                EXCLUDED.birth_date, EXCLUDED.region, EXCLUDED.segment)
        RETURNING (xmax = 0) AS was_insert
    )
    SELECT count(*) FILTER (WHERE was_insert), count(*) FILTER (WHERE NOT was_insert)
      INTO v_ins, v_upd FROM upserted;

    CALL etl.log_step(p_run_id, 'load_dim_customer', v_started,
                      v_read, v_dup, v_rej, v_ins, v_upd, v_valid - v_ins - v_upd);
END;
$$;

-- ---------------------------------------------------------------- dim_product
CREATE OR REPLACE PROCEDURE etl.load_dim_product(p_run_id BIGINT)
LANGUAGE plpgsql AS $$
DECLARE
    v_started TIMESTAMPTZ := clock_timestamp();
    v_read INT; v_rej INT; v_valid INT; v_ins INT; v_upd INT;
BEGIN
    SELECT count(*), count(*) FILTER (WHERE reject_reason IS NOT NULL),
           count(*) FILTER (WHERE reject_reason IS NULL)
      INTO v_read, v_rej, v_valid FROM etl.v_product_validated;

    INSERT INTO etl.data_quality_issue(run_id, entity, record_key, rule_code, severity, details, raw_record)
    SELECT p_run_id, 'product', product_code, reject_reason, 'ERROR', 'Row rejected', raw_record
      FROM etl.v_product_validated WHERE reject_reason IS NOT NULL;

    WITH upserted AS (
        INSERT INTO dw.dim_product AS t (product_code, product_name, line_of_business, base_annual_premium)
        SELECT product_code, product_name, line_of_business, base_annual_premium
          FROM etl.v_product_validated WHERE reject_reason IS NULL
        ON CONFLICT (product_code) DO UPDATE
           SET product_name = EXCLUDED.product_name, line_of_business = EXCLUDED.line_of_business,
               base_annual_premium = EXCLUDED.base_annual_premium, dw_updated_at = now()
         WHERE (t.product_name, t.line_of_business, t.base_annual_premium)
               IS DISTINCT FROM (EXCLUDED.product_name, EXCLUDED.line_of_business, EXCLUDED.base_annual_premium)
        RETURNING (xmax = 0) AS was_insert
    )
    SELECT count(*) FILTER (WHERE was_insert), count(*) FILTER (WHERE NOT was_insert)
      INTO v_ins, v_upd FROM upserted;

    CALL etl.log_step(p_run_id, 'load_dim_product', v_started,
                      v_read, 0, v_rej, v_ins, v_upd, v_valid - v_ins - v_upd);
END;
$$;

-- ---------------------------------------------------------------- dim_policy
CREATE OR REPLACE PROCEDURE etl.load_dim_policy(p_run_id BIGINT)
LANGUAGE plpgsql AS $$
DECLARE
    v_started TIMESTAMPTZ := clock_timestamp();
    v_read INT; v_dup INT; v_rej INT; v_valid INT; v_ins INT; v_upd INT;
BEGIN
    SELECT count(*), count(*) FILTER (WHERE reject_reason IS NOT NULL),
           count(*) FILTER (WHERE dup_rank > 1), count(*) FILTER (WHERE dup_rank = 1)
      INTO v_read, v_rej, v_dup, v_valid FROM etl.v_policy_validated;

    INSERT INTO etl.data_quality_issue(run_id, entity, record_key, rule_code, severity, details, raw_record)
    SELECT p_run_id, 'policy', policy_number, reject_reason, 'ERROR', 'Row rejected', raw_record
      FROM etl.v_policy_validated WHERE reject_reason IS NOT NULL;

    WITH upserted AS (
        INSERT INTO dw.dim_policy AS t
               (policy_number, customer_key, product_key, start_date, end_date,
                status, annual_premium, payment_frequency)
        SELECT policy_number, customer_key, product_key, start_date, end_date,
               status, annual_premium, payment_frequency
          FROM etl.v_policy_validated WHERE dup_rank = 1
        ON CONFLICT (policy_number) DO UPDATE
           SET customer_key = EXCLUDED.customer_key, product_key = EXCLUDED.product_key,
               start_date = EXCLUDED.start_date, end_date = EXCLUDED.end_date,
               status = EXCLUDED.status, annual_premium = EXCLUDED.annual_premium,
               payment_frequency = EXCLUDED.payment_frequency, dw_updated_at = now()
         WHERE (t.customer_key, t.product_key, t.start_date, t.end_date, t.status,
                t.annual_premium, t.payment_frequency)
               IS DISTINCT FROM
               (EXCLUDED.customer_key, EXCLUDED.product_key, EXCLUDED.start_date, EXCLUDED.end_date,
                EXCLUDED.status, EXCLUDED.annual_premium, EXCLUDED.payment_frequency)
        RETURNING (xmax = 0) AS was_insert
    )
    SELECT count(*) FILTER (WHERE was_insert), count(*) FILTER (WHERE NOT was_insert)
      INTO v_ins, v_upd FROM upserted;

    CALL etl.log_step(p_run_id, 'load_dim_policy', v_started,
                      v_read, v_dup, v_rej, v_ins, v_upd, v_valid - v_ins - v_upd);
END;
$$;

-- ---------------------------------------------------------------- fact_premium_payment
CREATE OR REPLACE PROCEDURE etl.load_fact_premium_payment(p_run_id BIGINT)
LANGUAGE plpgsql AS $$
DECLARE
    v_started TIMESTAMPTZ := clock_timestamp();
    v_read INT; v_rej INT; v_valid INT; v_ins INT; v_upd INT;
BEGIN
    SELECT count(*), count(*) FILTER (WHERE reject_reason IS NOT NULL),
           count(*) FILTER (WHERE reject_reason IS NULL)
      INTO v_read, v_rej, v_valid FROM etl.v_premium_validated;

    INSERT INTO etl.data_quality_issue(run_id, entity, record_key, rule_code, severity, details, raw_record)
    SELECT p_run_id, 'premium_payment', CAST(payment_id AS TEXT), reject_reason, 'ERROR', 'Row rejected', raw_record
      FROM etl.v_premium_validated WHERE reject_reason IS NOT NULL;

    WITH upserted AS (
        INSERT INTO dw.fact_premium_payment AS t
               (source_payment_id, policy_key, customer_key, product_key,
                payment_date_key, amount, payment_method)
        SELECT payment_id, policy_key, customer_key, product_key,
               payment_date_key, amount, payment_method
          FROM etl.v_premium_validated WHERE reject_reason IS NULL
        ON CONFLICT (source_payment_id) DO UPDATE
           SET policy_key = EXCLUDED.policy_key, customer_key = EXCLUDED.customer_key,
               product_key = EXCLUDED.product_key, payment_date_key = EXCLUDED.payment_date_key,
               amount = EXCLUDED.amount, payment_method = EXCLUDED.payment_method
         WHERE (t.policy_key, t.payment_date_key, t.amount, t.payment_method)
               IS DISTINCT FROM (EXCLUDED.policy_key, EXCLUDED.payment_date_key,
                                 EXCLUDED.amount, EXCLUDED.payment_method)
        RETURNING (xmax = 0) AS was_insert
    )
    SELECT count(*) FILTER (WHERE was_insert), count(*) FILTER (WHERE NOT was_insert)
      INTO v_ins, v_upd FROM upserted;

    CALL etl.log_step(p_run_id, 'load_fact_premium_payment', v_started,
                      v_read, 0, v_rej, v_ins, v_upd, v_valid - v_ins - v_upd);
END;
$$;

-- ---------------------------------------------------------------- fact_claim (latest state per claim)
CREATE OR REPLACE PROCEDURE etl.load_fact_claim(p_run_id BIGINT)
LANGUAGE plpgsql AS $$
DECLARE
    v_started TIMESTAMPTZ := clock_timestamp();
    v_read INT; v_dup INT; v_rej INT; v_valid INT; v_ins INT; v_upd INT;
BEGIN
    SELECT count(*), count(*) FILTER (WHERE reject_reason IS NOT NULL),
           count(*) FILTER (WHERE dup_rank > 1), count(*) FILTER (WHERE dup_rank = 1)
      INTO v_read, v_rej, v_dup, v_valid FROM etl.v_claim_validated;

    INSERT INTO etl.data_quality_issue(run_id, entity, record_key, rule_code, severity, details, raw_record)
    SELECT p_run_id, 'claim', claim_id, reject_reason, 'ERROR',
           CASE reject_reason
               WHEN 'ORPHAN_POLICY' THEN 'Policy ' || policy_number || ' not found in dim_policy'
               WHEN 'CLAIM_OUTSIDE_COVERAGE' THEN
                    'Claim date ' || claim_date || ' outside ' || policy_start || '..' || policy_end
               ELSE 'Row rejected'
           END, raw_record
      FROM etl.v_claim_validated WHERE reject_reason IS NOT NULL;

    INSERT INTO etl.data_quality_issue(run_id, entity, record_key, rule_code, severity, details, raw_record)
    SELECT p_run_id, 'claim', claim_id, 'DUPLICATE_RECORD', 'WARNING',
           'Duplicate claim row dropped', raw_record
      FROM etl.v_claim_validated WHERE dup_rank > 1;

    WITH upserted AS (
        INSERT INTO dw.fact_claim AS t
               (claim_id, policy_key, customer_key, product_key, claim_date_key,
                reported_date_key, claim_type, claim_status, claimed_amount, paid_amount)
        SELECT claim_id, policy_key, customer_key, product_key, claim_date_key,
               reported_date_key, claim_type, claim_status, claimed_amount, paid_amount
          FROM etl.v_claim_validated WHERE dup_rank = 1
        ON CONFLICT (claim_id) DO UPDATE
           SET claim_status = EXCLUDED.claim_status, claimed_amount = EXCLUDED.claimed_amount,
               paid_amount = EXCLUDED.paid_amount, claim_type = EXCLUDED.claim_type,
               reported_date_key = EXCLUDED.reported_date_key, dw_updated_at = now()
         WHERE (t.claim_status, t.claimed_amount, t.paid_amount, t.claim_type, t.reported_date_key)
               IS DISTINCT FROM (EXCLUDED.claim_status, EXCLUDED.claimed_amount,
                                 EXCLUDED.paid_amount, EXCLUDED.claim_type, EXCLUDED.reported_date_key)
        RETURNING (xmax = 0) AS was_insert
    )
    SELECT count(*) FILTER (WHERE was_insert), count(*) FILTER (WHERE NOT was_insert)
      INTO v_ins, v_upd FROM upserted;

    CALL etl.log_step(p_run_id, 'load_fact_claim', v_started,
                      v_read, v_dup, v_rej, v_ins, v_upd, v_valid - v_ins - v_upd);
END;
$$;
