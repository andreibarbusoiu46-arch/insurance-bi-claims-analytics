-- =====================================================================
-- 08_analytics_queries.sql   Ad-hoc business questions answered in SQL.
-- Each query demonstrates a specific technique (see the header comment).
-- Run with:  psql -d insurance_dw -f sql/08_analytics_queries.sql
-- =====================================================================

-- Q1. Top 10 customers by total paid claims, with their share of all payouts.
-- Technique: multi-table JOIN, GROUP BY, window aggregate over the whole set.
SELECT c.customer_id, c.first_name || ' ' || c.last_name AS customer,
       c.region, c.segment,
       COUNT(*)                  AS claims,
       SUM(f.paid_amount)        AS paid_total,
       ROUND(100.0 * SUM(f.paid_amount) / SUM(SUM(f.paid_amount)) OVER (), 2) AS pct_of_all_payouts
FROM dw.fact_claim f
JOIN dw.dim_customer c ON c.customer_key = f.customer_key
GROUP BY c.customer_id, c.first_name, c.last_name, c.region, c.segment
ORDER BY paid_total DESC
LIMIT 10;

-- Q2. Rank products by loss ratio inside each line of business.
-- Technique: CTE + RANK() with PARTITION BY.
WITH lr AS (
    SELECT p.line_of_business, p.product_name,
           SUM(k.claims_paid) / NULLIF(SUM(k.premium_collected), 0) AS loss_ratio
    FROM rpt.v_kpi_product_year k
    JOIN dw.dim_product p ON p.product_code = k.product_code
    GROUP BY p.line_of_business, p.product_name
)
SELECT line_of_business, product_name, ROUND(loss_ratio, 4) AS loss_ratio,
       RANK() OVER (PARTITION BY line_of_business ORDER BY loss_ratio DESC) AS rank_in_lob
FROM lr
ORDER BY line_of_business, rank_in_lob;

-- Q3. Claims whose amount is above the average of their own product.
-- Technique: correlated subquery (then compare with the window version below).
SELECT f.claim_id, p.product_code, f.claimed_amount
FROM dw.fact_claim f
JOIN dw.dim_product p ON p.product_key = f.product_key
WHERE f.claimed_amount > (SELECT AVG(f2.claimed_amount)
                          FROM dw.fact_claim f2
                          WHERE f2.product_key = f.product_key)
ORDER BY f.claimed_amount DESC
LIMIT 10;

-- Q3b. Same result, one pass over the table: window AVG instead of correlated subquery.
SELECT claim_id, product_code, claimed_amount
FROM (SELECT f.claim_id, p.product_code, f.claimed_amount,
             AVG(f.claimed_amount) OVER (PARTITION BY f.product_key) AS product_avg
      FROM dw.fact_claim f JOIN dw.dim_product p ON p.product_key = f.product_key) x
WHERE claimed_amount > product_avg
ORDER BY claimed_amount DESC
LIMIT 10;

-- Q4. Policies that never had a claim, per product (anti-join).
-- Technique: NOT EXISTS (safe with NULLs, unlike NOT IN).
SELECT p.product_code, COUNT(*) AS policies_without_claims
FROM dw.dim_policy pol
JOIN dw.dim_product p ON p.product_key = pol.product_key
WHERE NOT EXISTS (SELECT 1 FROM dw.fact_claim f WHERE f.policy_key = pol.policy_key)
GROUP BY p.product_code
ORDER BY policies_without_claims DESC;

-- Q5. Claim reporting lag distribution per claim type.
-- Technique: ordered-set aggregates (median / p90).
SELECT claim_type,
       COUNT(*) AS claims,
       percentile_cont(0.5) WITHIN GROUP (ORDER BY reporting_lag_days) AS median_lag_days,
       percentile_cont(0.9) WITHIN GROUP (ORDER BY reporting_lag_days) AS p90_lag_days
FROM rpt.fact_claim
GROUP BY claim_type
ORDER BY p90_lag_days DESC;

-- Q6. Customers with two claims less than 90 days apart (possible fraud signal).
-- Technique: LAG() over a per-customer ordered window.
WITH ordered AS (
    SELECT f.customer_key, f.claim_id, d.full_date AS claim_date,
           LAG(d.full_date) OVER (PARTITION BY f.customer_key ORDER BY d.full_date) AS prev_claim_date
    FROM dw.fact_claim f
    JOIN dw.dim_date d ON d.date_key = f.claim_date_key
)
SELECT c.customer_id, o.claim_id, o.prev_claim_date, o.claim_date,
       o.claim_date - o.prev_claim_date AS days_between
FROM ordered o
JOIN dw.dim_customer c ON c.customer_key = o.customer_key
WHERE o.claim_date - o.prev_claim_date < 90
ORDER BY days_between;

-- Q7. Region share of claims vs share of policies (is a region over-represented?).
-- Technique: two aggregations joined + ratio of window totals.
WITH pol AS (
    SELECT c.region, COUNT(*) AS policies
    FROM dw.dim_policy p JOIN dw.dim_customer c ON c.customer_key = p.customer_key
    GROUP BY c.region
), clm AS (
    SELECT c.region, COUNT(*) AS claims
    FROM dw.fact_claim f JOIN dw.dim_customer c ON c.customer_key = f.customer_key
    GROUP BY c.region
)
SELECT pol.region,
       ROUND(100.0 * pol.policies / SUM(pol.policies) OVER (), 1)          AS pct_policies,
       ROUND(100.0 * COALESCE(clm.claims, 0) / SUM(clm.claims) OVER (), 1) AS pct_claims
FROM pol LEFT JOIN clm ON clm.region = pol.region
ORDER BY pct_claims DESC;
