-- =====================================================================
-- 03_dw_tables.sql   Dimensional model (star schema)
--   Dimensions: dim_date, dim_customer, dim_product, dim_policy
--   Facts:      fact_premium_payment (revenue), fact_claim (losses)
-- Surrogate keys (xxx_key) are owned by the warehouse; business keys
-- (customer_id, policy_number ...) come from sources and are UNIQUE.
-- Constraints are the LAST line of defence: the ETL validates first, so
-- in a healthy run no constraint should ever fire.
-- =====================================================================

CREATE TABLE IF NOT EXISTS dw.dim_date (
    date_key      INT PRIMARY KEY,                -- yyyymmdd, e.g. 20240315
    full_date     DATE NOT NULL UNIQUE,
    year          SMALLINT NOT NULL,
    quarter       SMALLINT NOT NULL CHECK (quarter BETWEEN 1 AND 4),
    month         SMALLINT NOT NULL CHECK (month BETWEEN 1 AND 12),
    month_name    VARCHAR(10) NOT NULL,
    year_month    CHAR(7) NOT NULL,               -- '2024-03'
    is_weekend    BOOLEAN NOT NULL
);

INSERT INTO dw.dim_date
SELECT CAST(to_char(d, 'YYYYMMDD') AS INT), d,
       EXTRACT(YEAR FROM d), EXTRACT(QUARTER FROM d), EXTRACT(MONTH FROM d),
       trim(to_char(d, 'Month')), to_char(d, 'YYYY-MM'),
       EXTRACT(ISODOW FROM d) IN (6, 7)
FROM generate_series(DATE '2020-01-01', DATE '2027-12-31', INTERVAL '1 day') AS g(d)
ON CONFLICT (date_key) DO NOTHING;

CREATE TABLE IF NOT EXISTS dw.dim_customer (
    customer_key       INT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    customer_id        VARCHAR(10)  NOT NULL UNIQUE,     -- business key (CRM)
    first_name         VARCHAR(50)  NOT NULL,
    last_name          VARCHAR(50)  NOT NULL,
    email              VARCHAR(120),
    birth_date         DATE CHECK (birth_date BETWEEN DATE '1900-01-01' AND CURRENT_DATE),
    region             VARCHAR(40)  NOT NULL DEFAULT 'Unknown',
    segment            VARCHAR(20)  NOT NULL DEFAULT 'Unknown',
    source_updated_at  DATE,
    dw_inserted_at     TIMESTAMPTZ  NOT NULL DEFAULT now(),
    dw_updated_at      TIMESTAMPTZ  NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS dw.dim_product (
    product_key          INT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    product_code         VARCHAR(20)  NOT NULL UNIQUE,
    product_name         VARCHAR(100) NOT NULL,
    line_of_business     VARCHAR(30)  NOT NULL,
    base_annual_premium  NUMERIC(12,2) NOT NULL CHECK (base_annual_premium > 0),
    dw_updated_at        TIMESTAMPTZ  NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS dw.dim_policy (
    policy_key         INT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    policy_number      VARCHAR(20) NOT NULL UNIQUE,
    customer_key       INT NOT NULL REFERENCES dw.dim_customer(customer_key),
    product_key        INT NOT NULL REFERENCES dw.dim_product(product_key),
    start_date         DATE NOT NULL,
    end_date           DATE NOT NULL,
    status             VARCHAR(15) NOT NULL CHECK (status IN ('ACTIVE', 'EXPIRED', 'CANCELLED')),
    annual_premium     NUMERIC(12,2) NOT NULL CHECK (annual_premium >= 0),
    payment_frequency  VARCHAR(15) NOT NULL CHECK (payment_frequency IN ('ANNUAL', 'QUARTERLY', 'MONTHLY')),
    dw_updated_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    CONSTRAINT ck_policy_period CHECK (end_date > start_date)
);
CREATE INDEX IF NOT EXISTS ix_dim_policy_customer ON dw.dim_policy(customer_key);
CREATE INDEX IF NOT EXISTS ix_dim_policy_product  ON dw.dim_policy(product_key);

-- Grain: one row per premium payment received
CREATE TABLE IF NOT EXISTS dw.fact_premium_payment (
    premium_payment_key  BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    source_payment_id    INT NOT NULL UNIQUE,
    policy_key           INT NOT NULL REFERENCES dw.dim_policy(policy_key),
    customer_key         INT NOT NULL REFERENCES dw.dim_customer(customer_key),
    product_key          INT NOT NULL REFERENCES dw.dim_product(product_key),
    payment_date_key     INT NOT NULL REFERENCES dw.dim_date(date_key),
    amount               NUMERIC(12,2) NOT NULL CHECK (amount > 0),
    payment_method       VARCHAR(20) NOT NULL
);
CREATE INDEX IF NOT EXISTS ix_fpp_date    ON dw.fact_premium_payment(payment_date_key);
CREATE INDEX IF NOT EXISTS ix_fpp_policy  ON dw.fact_premium_payment(policy_key);
CREATE INDEX IF NOT EXISTS ix_fpp_product ON dw.fact_premium_payment(product_key);

-- Grain: one row per claim (latest known state)
CREATE TABLE IF NOT EXISTS dw.fact_claim (
    claim_key          BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    claim_id           VARCHAR(20) NOT NULL UNIQUE,
    policy_key         INT NOT NULL REFERENCES dw.dim_policy(policy_key),
    customer_key       INT NOT NULL REFERENCES dw.dim_customer(customer_key),
    product_key        INT NOT NULL REFERENCES dw.dim_product(product_key),
    claim_date_key     INT NOT NULL REFERENCES dw.dim_date(date_key),
    reported_date_key  INT NOT NULL REFERENCES dw.dim_date(date_key),
    claim_type         VARCHAR(40) NOT NULL,
    claim_status       VARCHAR(10) NOT NULL CHECK (claim_status IN ('OPEN', 'PAID', 'REJECTED')),
    claimed_amount     NUMERIC(12,2) NOT NULL CHECK (claimed_amount > 0),
    paid_amount        NUMERIC(12,2) NOT NULL DEFAULT 0 CHECK (paid_amount >= 0),
    dw_updated_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    CONSTRAINT ck_paid_le_claimed CHECK (paid_amount <= claimed_amount),
    CONSTRAINT ck_reported_after_claim CHECK (reported_date_key >= claim_date_key)
);
CREATE INDEX IF NOT EXISTS ix_fc_claim_date ON dw.fact_claim(claim_date_key);
CREATE INDEX IF NOT EXISTS ix_fc_policy     ON dw.fact_claim(policy_key);
CREATE INDEX IF NOT EXISTS ix_fc_product    ON dw.fact_claim(product_key);
CREATE INDEX IF NOT EXISTS ix_fc_customer   ON dw.fact_claim(customer_key);
