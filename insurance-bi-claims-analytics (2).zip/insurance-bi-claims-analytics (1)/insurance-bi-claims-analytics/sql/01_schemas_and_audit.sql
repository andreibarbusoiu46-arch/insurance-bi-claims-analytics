-- =====================================================================
-- 01_schemas_and_audit.sql   (run against database: insurance_dw)
-- Layered architecture:
--   stg  = raw copy of source data, truncated & reloaded each run
--   dw   = cleaned, validated, conformed dimensional model (star schema)
--   rpt  = reporting views consumed by Power BI
--   etl  = pipeline metadata: runs, steps, data-quality issues
-- =====================================================================
CREATE SCHEMA IF NOT EXISTS stg;
CREATE SCHEMA IF NOT EXISTS dw;
CREATE SCHEMA IF NOT EXISTS rpt;
CREATE SCHEMA IF NOT EXISTS etl;

-- One row per pipeline execution
CREATE TABLE IF NOT EXISTS etl.job_run (
    run_id          BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    job_name        VARCHAR(100) NOT NULL,
    status          VARCHAR(10)  NOT NULL DEFAULT 'RUNNING'
                    CHECK (status IN ('RUNNING', 'SUCCESS', 'FAILED')),
    started_at      TIMESTAMPTZ  NOT NULL DEFAULT clock_timestamp(),
    finished_at     TIMESTAMPTZ,
    error_message   TEXT,
    triggered_by    VARCHAR(100) NOT NULL DEFAULT current_user
);

-- One row per step (extract / load / test) inside a run
CREATE TABLE IF NOT EXISTS etl.step_log (
    step_log_id     BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    run_id          BIGINT NOT NULL REFERENCES etl.job_run(run_id),
    step_name       VARCHAR(100) NOT NULL,
    rows_read       INT NOT NULL DEFAULT 0,
    rows_duplicate  INT NOT NULL DEFAULT 0,
    rows_rejected   INT NOT NULL DEFAULT 0,
    rows_inserted   INT NOT NULL DEFAULT 0,
    rows_updated    INT NOT NULL DEFAULT 0,
    rows_unchanged  INT NOT NULL DEFAULT 0,
    started_at      TIMESTAMPTZ NOT NULL,
    finished_at     TIMESTAMPTZ NOT NULL DEFAULT clock_timestamp(),
    duration_ms     INT GENERATED ALWAYS AS
                    (CAST(EXTRACT(EPOCH FROM (finished_at - started_at)) * 1000 AS INT)) STORED
);
CREATE INDEX IF NOT EXISTS ix_step_log_run ON etl.step_log(run_id);

-- Every rule violation found during validation.
--   severity ERROR   -> row was rejected (not loaded)
--   severity WARNING -> row was loaded after a documented correction
CREATE TABLE IF NOT EXISTS etl.data_quality_issue (
    issue_id        BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    run_id          BIGINT NOT NULL REFERENCES etl.job_run(run_id),
    entity          VARCHAR(50)  NOT NULL,
    record_key      VARCHAR(50),
    rule_code       VARCHAR(50)  NOT NULL,
    severity        VARCHAR(10)  NOT NULL CHECK (severity IN ('ERROR', 'WARNING')),
    details         TEXT,
    raw_record      JSONB,
    logged_at       TIMESTAMPTZ NOT NULL DEFAULT clock_timestamp()
);
CREATE INDEX IF NOT EXISTS ix_dq_issue_run ON etl.data_quality_issue(run_id, entity);
