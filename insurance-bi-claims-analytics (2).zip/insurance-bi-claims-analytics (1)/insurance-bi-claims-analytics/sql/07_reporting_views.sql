-- =====================================================================
-- 07_reporting_views.sql   The ONLY schema Power BI connects to.
-- Thin views over dw tables form a stable contract: the warehouse can be
-- refactored (rename columns, split tables) without breaking the report.
-- Power BI imports the star schema (dims + facts) and computes KPIs in
-- DAX; the aggregated views below are for SQL-side validation of those
-- DAX numbers and for the ETL monitoring page.
-- =====================================================================

-- ---------------- star schema contract ----------------
CREATE OR REPLACE VIEW rpt.dim_date AS
SELECT date_key, full_date, year, quarter, month, month_name, year_month, is_weekend
FROM dw.dim_date
WHERE full_date BETWEEN DATE '2023-01-01' AND DATE '2025-12-31';

CREATE OR REPLACE VIEW rpt.dim_customer AS
SELECT customer_key, customer_id, first_name || ' ' || last_name AS customer_name,
       region, segment,
       CASE
           WHEN birth_date IS NULL THEN 'Unknown'
           WHEN age(CURRENT_DATE, birth_date) < INTERVAL '30 years' THEN '18-29'
           WHEN age(CURRENT_DATE, birth_date) < INTERVAL '45 years' THEN '30-44'
           WHEN age(CURRENT_DATE, birth_date) < INTERVAL '60 years' THEN '45-59'
           ELSE '60+'
       END AS age_band
FROM dw.dim_customer;

CREATE OR REPLACE VIEW rpt.dim_product AS
SELECT product_key, product_code, product_name, line_of_business FROM dw.dim_product;

CREATE OR REPLACE VIEW rpt.dim_policy AS
SELECT policy_key, policy_number, customer_key, product_key, start_date, end_date,
       status, annual_premium, payment_frequency,
       CAST(to_char(start_date, 'YYYYMMDD') AS INT) AS start_date_key
FROM dw.dim_policy;

CREATE OR REPLACE VIEW rpt.fact_claim AS
SELECT claim_key, claim_id, policy_key, customer_key, product_key, claim_date_key,
       reported_date_key, claim_type, claim_status, claimed_amount, paid_amount,
       (to_date(CAST(reported_date_key AS TEXT), 'YYYYMMDD')
        - to_date(CAST(claim_date_key AS TEXT), 'YYYYMMDD')) AS reporting_lag_days
FROM dw.fact_claim;

CREATE OR REPLACE VIEW rpt.fact_premium_payment AS
SELECT premium_payment_key, policy_key, customer_key, product_key,
       payment_date_key, amount, payment_method
FROM dw.fact_premium_payment;

-- ---------------- KPI by product & year (CTEs + joins + aggregation) ----------------
-- loss ratio here = paid claims / collected premium (cash basis).
-- A real actuarial loss ratio uses EARNED premium and INCURRED losses
-- (paid + reserves); this is documented as a simplification.
CREATE OR REPLACE VIEW rpt.v_kpi_product_year AS
WITH premium AS (
    SELECT f.product_key, d.year, SUM(f.amount) AS premium_collected
    FROM dw.fact_premium_payment f
    JOIN dw.dim_date d ON d.date_key = f.payment_date_key
    GROUP BY f.product_key, d.year
),
claims AS (
    SELECT c.product_key, d.year,
           COUNT(*)              AS claim_count,
           SUM(c.claimed_amount) AS claimed_total,
           SUM(c.paid_amount)    AS paid_total
    FROM dw.fact_claim c
    JOIN dw.dim_date d ON d.date_key = c.claim_date_key
    GROUP BY c.product_key, d.year
),
policies AS (   -- policies in force at any point during the year
    SELECT p.product_key, y.year, COUNT(*) AS policies_in_force
    FROM dw.dim_policy p
    JOIN (VALUES (2023), (2024)) AS y(year)   -- years covered by source data
      ON p.start_date <= make_date(y.year, 12, 31) AND p.end_date >= make_date(y.year, 1, 1)
    GROUP BY p.product_key, y.year
)
SELECT pr.product_code, pr.product_name, pr.line_of_business, po.year,
       po.policies_in_force,
       COALESCE(cl.claim_count, 0)                                        AS claim_count,
       ROUND(COALESCE(cl.claim_count, 0)::NUMERIC / po.policies_in_force, 4) AS claim_frequency,
       ROUND(cl.claimed_total / NULLIF(cl.claim_count, 0), 2)             AS claim_severity,
       COALESCE(pm.premium_collected, 0)                                  AS premium_collected,
       COALESCE(cl.paid_total, 0)                                         AS claims_paid,
       ROUND(cl.paid_total / NULLIF(pm.premium_collected, 0), 4)          AS loss_ratio
FROM policies po
JOIN dw.dim_product pr ON pr.product_key = po.product_key
LEFT JOIN premium pm ON pm.product_key = po.product_key AND pm.year = po.year
LEFT JOIN claims  cl ON cl.product_key = po.product_key AND cl.year = po.year;

-- ---------------- monthly trend (window functions: running total, LAG) ----------------
CREATE OR REPLACE VIEW rpt.v_monthly_trend AS
WITH months AS (
    SELECT DISTINCT year, month, year_month FROM dw.dim_date
    WHERE full_date BETWEEN DATE '2023-01-01' AND DATE '2024-12-31'
),
prem AS (
    SELECT d.year_month, SUM(f.amount) AS premium
    FROM dw.fact_premium_payment f JOIN dw.dim_date d ON d.date_key = f.payment_date_key
    GROUP BY d.year_month
),
clm AS (
    SELECT d.year_month, COUNT(*) AS claims, SUM(c.paid_amount) AS paid
    FROM dw.fact_claim c JOIN dw.dim_date d ON d.date_key = c.claim_date_key
    GROUP BY d.year_month
),
base AS (
    SELECT m.year, m.month, m.year_month,
           COALESCE(p.premium, 0) AS premium,
           COALESCE(c.claims, 0)  AS claims,
           COALESCE(c.paid, 0)    AS paid
    FROM months m
    LEFT JOIN prem p ON p.year_month = m.year_month
    LEFT JOIN clm  c ON c.year_month = m.year_month
)
SELECT year_month, premium, claims, paid,
       SUM(premium) OVER (PARTITION BY year ORDER BY month)            AS premium_ytd,
       SUM(paid)    OVER (PARTITION BY year ORDER BY month)            AS paid_ytd,
       claims - LAG(claims) OVER (ORDER BY year, month)                AS claims_change_mom,
       ROUND(AVG(claims) OVER (ORDER BY year, month
                               ROWS BETWEEN 2 PRECEDING AND CURRENT ROW), 1) AS claims_3m_moving_avg
FROM base;

-- ---------------- ETL monitoring (for the "Data Quality" report page) ----------------
CREATE OR REPLACE VIEW rpt.v_etl_run_summary AS
SELECT r.run_id, r.job_name, r.status, r.started_at, r.finished_at,
       ROUND(EXTRACT(EPOCH FROM (r.finished_at - r.started_at))::NUMERIC, 2) AS duration_sec,
       SUM(s.rows_read)      AS rows_read,
       SUM(s.rows_inserted)  AS rows_inserted,
       SUM(s.rows_updated)   AS rows_updated,
       SUM(s.rows_unchanged) AS rows_unchanged,
       SUM(s.rows_duplicate) AS rows_duplicate,
       SUM(s.rows_rejected)  AS rows_rejected,
       r.error_message
FROM etl.job_run r
LEFT JOIN etl.step_log s ON s.run_id = r.run_id AND s.step_name LIKE 'load_%'
GROUP BY r.run_id;

CREATE OR REPLACE VIEW rpt.v_dq_issue_summary AS
SELECT run_id, entity, rule_code, severity, COUNT(*) AS issue_count
FROM etl.data_quality_issue
GROUP BY run_id, entity, rule_code, severity;
