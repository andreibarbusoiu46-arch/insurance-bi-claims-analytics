-- =====================================================================
-- 05_validation_views.sql
-- One view per entity. Each view:
--   1. parses/cleans raw staging values
--   2. performs lookups to the warehouse (surrogate keys)
--   3. assigns reject_reason = FIRST failed blocking rule (NULL = valid)
--   4. assigns dup_rank among VALID rows (1 = the version we keep)
-- The load procedures only read these views, so validation logic lives
-- in one place and can be inspected with a plain SELECT before loading.
-- =====================================================================

-- ---------------------------------------------------------------- customers
CREATE OR REPLACE VIEW etl.v_customer_validated AS
WITH parsed AS (
    SELECT s.stg_row_id,
           NULLIF(trim(s.customer_id), '')                 AS customer_id,
           etl.clean_name(s.first_name)                    AS first_name,
           etl.clean_name(s.last_name)                     AS last_name,
           lower(NULLIF(trim(s.email), ''))                AS email_raw,
           NULLIF(trim(s.birth_date), '')                  AS birth_date_raw,
           etl.try_parse_date(s.birth_date)                AS birth_date_parsed,
           NULLIF(trim(s.region), '')                      AS region_raw,
           NULLIF(trim(s.segment), '')                     AS segment_raw,
           etl.try_parse_date(s.last_updated)              AS last_updated,
           to_jsonb(s) - 'stg_row_id' - 'loaded_at'        AS raw_record
    FROM stg.crm_customers s
),
checked AS (
    SELECT p.*,
           CASE WHEN p.birth_date_parsed BETWEEN DATE '1900-01-01' AND CURRENT_DATE
                THEN p.birth_date_parsed END                             AS birth_date,
           CASE WHEN p.email_raw ~ '^[^@\s]+@[^@\s]+\.[a-z]{2,}$'
                THEN p.email_raw END                                     AS email,
           COALESCE(p.region_raw, 'Unknown')                             AS region,
           CASE WHEN p.segment_raw IN ('Retail', 'Premium', 'SME')
                THEN p.segment_raw ELSE 'Unknown' END                    AS segment,
           CASE
               WHEN p.customer_id IS NULL                      THEN 'MISSING_BUSINESS_KEY'
               WHEN p.first_name IS NULL OR p.last_name IS NULL THEN 'MISSING_NAME'
           END                                                           AS reject_reason
    FROM parsed p
)
SELECT c.*,
       CASE WHEN c.reject_reason IS NULL THEN
           ROW_NUMBER() OVER (PARTITION BY c.customer_id, (c.reject_reason IS NULL)
                              ORDER BY c.last_updated DESC NULLS LAST, c.stg_row_id DESC)
       END AS dup_rank
FROM checked c;

-- ---------------------------------------------------------------- products
CREATE OR REPLACE VIEW etl.v_product_validated AS
SELECT s.product_code, trim(s.product_name) AS product_name,
       trim(s.line_of_business) AS line_of_business, s.base_annual_premium,
       to_jsonb(s) - 'loaded_at' AS raw_record,
       CASE
           WHEN s.product_code IS NULL OR s.product_name IS NULL THEN 'MISSING_BUSINESS_KEY'
           WHEN s.base_annual_premium IS NULL OR s.base_annual_premium <= 0 THEN 'INVALID_BASE_PREMIUM'
       END AS reject_reason,
       1 AS dup_rank          -- source PK guarantees uniqueness
FROM stg.products s;

-- ---------------------------------------------------------------- policies
CREATE OR REPLACE VIEW etl.v_policy_validated AS
WITH checked AS (
    SELECT s.policy_number, s.customer_id, s.product_code, s.start_date, s.end_date,
           upper(trim(s.status)) AS status, s.annual_premium,
           upper(trim(s.payment_frequency)) AS payment_frequency, s.updated_at,
           c.customer_key, p.product_key,                           -- lookups
           to_jsonb(s) - 'loaded_at' AS raw_record,
           CASE
               WHEN s.policy_number IS NULL                        THEN 'MISSING_BUSINESS_KEY'
               WHEN c.customer_key IS NULL                         THEN 'ORPHAN_CUSTOMER'
               WHEN p.product_key IS NULL                          THEN 'UNKNOWN_PRODUCT'
               WHEN s.end_date <= s.start_date                     THEN 'INVALID_POLICY_PERIOD'
               WHEN upper(trim(s.status)) NOT IN ('ACTIVE', 'EXPIRED', 'CANCELLED') THEN 'INVALID_STATUS'
               WHEN s.annual_premium < 0                           THEN 'NEGATIVE_PREMIUM'
           END AS reject_reason
    FROM stg.policies s
    LEFT JOIN dw.dim_customer c ON c.customer_id  = s.customer_id
    LEFT JOIN dw.dim_product  p ON p.product_code = s.product_code
)
SELECT ch.*,
       CASE WHEN ch.reject_reason IS NULL THEN
           ROW_NUMBER() OVER (PARTITION BY ch.policy_number, (ch.reject_reason IS NULL)
                              ORDER BY ch.updated_at DESC)
       END AS dup_rank
FROM checked ch;

-- ---------------------------------------------------------------- premium payments
CREATE OR REPLACE VIEW etl.v_premium_validated AS
SELECT s.payment_id, s.policy_number, s.payment_date, s.amount, s.payment_method,
       pol.policy_key, pol.customer_key, pol.product_key, d.date_key AS payment_date_key,
       to_jsonb(s) - 'loaded_at' AS raw_record,
       CASE
           WHEN s.payment_id IS NULL      THEN 'MISSING_BUSINESS_KEY'
           WHEN pol.policy_key IS NULL    THEN 'ORPHAN_POLICY'
           WHEN d.date_key IS NULL        THEN 'DATE_OUT_OF_RANGE'
           WHEN s.amount IS NULL OR s.amount <= 0 THEN 'INVALID_AMOUNT'
       END AS reject_reason,
       1 AS dup_rank
FROM stg.premium_payments s
LEFT JOIN dw.dim_policy pol ON pol.policy_number = s.policy_number
LEFT JOIN dw.dim_date   d   ON d.full_date       = s.payment_date;

-- ---------------------------------------------------------------- claims
CREATE OR REPLACE VIEW etl.v_claim_validated AS
WITH parsed AS (
    SELECT s.stg_row_id,
           NULLIF(trim(s.claim_id), '')              AS claim_id,
           NULLIF(trim(s.policy_number), '')         AS policy_number,
           etl.try_parse_date(s.claim_date)          AS claim_date,
           etl.try_parse_date(s.reported_date)       AS reported_date_parsed,
           NULLIF(trim(s.claim_type), '')            AS claim_type,
           upper(trim(s.claim_status))               AS claim_status,
           etl.try_parse_numeric(s.claimed_amount)   AS claimed_amount,
           NULLIF(trim(s.paid_amount), '')           AS paid_amount_raw,
           COALESCE(etl.try_parse_numeric(s.paid_amount), 0) AS paid_amount,
           to_jsonb(s) - 'stg_row_id' - 'loaded_at'  AS raw_record
    FROM stg.claims s
),
checked AS (
    SELECT p.*,
           pol.policy_key, pol.customer_key, pol.product_key,
           pol.start_date AS policy_start, pol.end_date AS policy_end,
           GREATEST(COALESCE(p.reported_date_parsed, p.claim_date), p.claim_date) AS reported_date,
           CASE
               WHEN p.claim_id IS NULL                          THEN 'MISSING_BUSINESS_KEY'
               WHEN p.claim_date IS NULL                        THEN 'INVALID_CLAIM_DATE'
               WHEN pol.policy_key IS NULL                      THEN 'ORPHAN_POLICY'
               WHEN p.claim_date NOT BETWEEN pol.start_date AND pol.end_date
                                                                THEN 'CLAIM_OUTSIDE_COVERAGE'
               WHEN p.claimed_amount IS NULL OR p.claimed_amount <= 0
                                                                THEN 'INVALID_CLAIMED_AMOUNT'
               WHEN p.paid_amount_raw IS NOT NULL
                    AND etl.try_parse_numeric(p.paid_amount_raw) IS NULL
                                                                THEN 'INVALID_PAID_AMOUNT'
               WHEN p.paid_amount < 0                           THEN 'INVALID_PAID_AMOUNT'
               WHEN p.paid_amount > p.claimed_amount            THEN 'PAID_EXCEEDS_CLAIMED'
               WHEN p.claim_status NOT IN ('OPEN', 'PAID', 'REJECTED')
                                                                THEN 'INVALID_STATUS'
               WHEN p.claim_type IS NULL                        THEN 'MISSING_CLAIM_TYPE'
           END AS reject_reason
    FROM parsed p
    LEFT JOIN dw.dim_policy pol ON pol.policy_number = p.policy_number
)
SELECT ch.*,
       CAST(to_char(ch.claim_date, 'YYYYMMDD') AS INT)    AS claim_date_key,
       CAST(to_char(ch.reported_date, 'YYYYMMDD') AS INT) AS reported_date_key,
       CASE WHEN ch.reject_reason IS NULL THEN
           ROW_NUMBER() OVER (PARTITION BY ch.claim_id, (ch.reject_reason IS NULL)
                              ORDER BY ch.stg_row_id DESC)
       END AS dup_rank
FROM checked ch;
