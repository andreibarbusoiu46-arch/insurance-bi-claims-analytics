-- =====================================================================
-- 04_etl_functions.sql   Reusable ETL helpers
-- =====================================================================

-- Parse a date written in any of the formats seen in source exports.
-- Returns NULL instead of raising, so ONE bad row cannot abort the load;
-- the caller decides whether NULL means "reject" or "warn".
CREATE OR REPLACE FUNCTION etl.try_parse_date(p_value TEXT)
RETURNS DATE
LANGUAGE plpgsql IMMUTABLE AS $$
DECLARE
    v TEXT := trim(p_value);
BEGIN
    IF v IS NULL OR v = '' THEN
        RETURN NULL;
    ELSIF v ~ '^\d{4}-\d{2}-\d{2}$' THEN
        RETURN to_date(v, 'YYYY-MM-DD');
    ELSIF v ~ '^\d{2}/\d{2}/\d{4}$' THEN
        RETURN to_date(v, 'DD/MM/YYYY');
    ELSIF v ~ '^\d{2}\.\d{2}\.\d{4}$' THEN
        RETURN to_date(v, 'DD.MM.YYYY');
    END IF;
    RETURN NULL;
EXCEPTION
    WHEN others THEN          -- e.g. 31/02/1990, 2024-13-45
        RETURN NULL;
END;
$$;

CREATE OR REPLACE FUNCTION etl.try_parse_numeric(p_value TEXT)
RETURNS NUMERIC
LANGUAGE plpgsql IMMUTABLE AS $$
BEGIN
    IF p_value IS NULL OR trim(p_value) = '' THEN
        RETURN NULL;
    END IF;
    RETURN CAST(replace(trim(p_value), ',', '.') AS NUMERIC);
EXCEPTION
    WHEN others THEN
        RETURN NULL;
END;
$$;

-- "  ANDREI " -> "Andrei"
CREATE OR REPLACE FUNCTION etl.clean_name(p_value TEXT)
RETURNS TEXT
LANGUAGE sql IMMUTABLE AS $$
    SELECT NULLIF(initcap(regexp_replace(trim(p_value), '\s+', ' ', 'g')), '');
$$;

-- ---------------- run / step bookkeeping ----------------
CREATE OR REPLACE FUNCTION etl.start_run(p_job_name TEXT)
RETURNS BIGINT
LANGUAGE sql AS $$
    INSERT INTO etl.job_run(job_name) VALUES (p_job_name) RETURNING run_id;
$$;

CREATE OR REPLACE PROCEDURE etl.finish_run(p_run_id BIGINT, p_status TEXT, p_error TEXT DEFAULT NULL)
LANGUAGE sql AS $$
    UPDATE etl.job_run
       SET status = p_status, finished_at = clock_timestamp(), error_message = p_error
     WHERE run_id = p_run_id;
$$;

CREATE OR REPLACE PROCEDURE etl.log_step(
    p_run_id BIGINT, p_step TEXT, p_started TIMESTAMPTZ,
    p_read INT, p_dup INT DEFAULT 0, p_rej INT DEFAULT 0,
    p_ins INT DEFAULT 0, p_upd INT DEFAULT 0, p_unch INT DEFAULT 0)
LANGUAGE sql AS $$
    INSERT INTO etl.step_log(run_id, step_name, started_at, rows_read,
                             rows_duplicate, rows_rejected, rows_inserted, rows_updated, rows_unchanged)
    VALUES (p_run_id, p_step, p_started, p_read, p_dup, p_rej, p_ins, p_upd, p_unch);
$$;
