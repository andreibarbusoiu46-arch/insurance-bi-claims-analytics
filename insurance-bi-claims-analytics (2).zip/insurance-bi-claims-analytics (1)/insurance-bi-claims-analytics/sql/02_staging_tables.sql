-- =====================================================================
-- 02_staging_tables.sql
-- CSV sources land as TEXT: nothing can fail on load, so bad values are
-- captured and handled by explicit validation rules instead of crashing
-- the extract. Database sources are already typed, so staging mirrors
-- their types. stg_row_id gives every raw row a traceable identity.
-- =====================================================================
CREATE TABLE IF NOT EXISTS stg.crm_customers (          -- source: CRM CSV export
    stg_row_id    BIGINT GENERATED ALWAYS AS IDENTITY,
    customer_id   TEXT, first_name TEXT, last_name TEXT, email TEXT,
    birth_date    TEXT, region TEXT, segment TEXT, last_updated TEXT,
    loaded_at     TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS stg.claims (                 -- source: Claims system CSV export
    stg_row_id     BIGINT GENERATED ALWAYS AS IDENTITY,
    claim_id TEXT, policy_number TEXT, claim_date TEXT, reported_date TEXT,
    claim_type TEXT, claimed_amount TEXT, paid_amount TEXT, claim_status TEXT,
    loaded_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS stg.products (               -- source: src_policy_admin DB
    product_code VARCHAR(20), product_name VARCHAR(100),
    line_of_business VARCHAR(30), base_annual_premium NUMERIC(12,2),
    loaded_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS stg.policies (
    policy_number VARCHAR(20), customer_id VARCHAR(10), product_code VARCHAR(20),
    start_date DATE, end_date DATE, status VARCHAR(15),
    annual_premium NUMERIC(12,2), payment_frequency VARCHAR(15), updated_at TIMESTAMP,
    loaded_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS stg.premium_payments (
    payment_id INT, policy_number VARCHAR(20), payment_date DATE,
    amount NUMERIC(12,2), payment_method VARCHAR(20),
    loaded_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
