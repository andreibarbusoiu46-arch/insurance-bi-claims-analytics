# Architecture

## 1. High-level data flow

```mermaid
flowchart LR
    subgraph SRC[Source systems]
        CRM[CRM export<br/>crm_customers.csv]
        CLM[Claims system export<br/>claims_export.csv]
        PAS[(Policy Admin DB<br/>src_policy_admin<br/>products, policies,<br/>premium_payments)]
    end

    subgraph DW[(insurance_dw - PostgreSQL)]
        STG[stg schema<br/>raw, TEXT for CSV<br/>truncate + reload]
        VAL[etl validation views<br/>parse, lookup,<br/>reject_reason, dup_rank]
        CORE[dw schema<br/>star schema<br/>dims + facts]
        RPT[rpt schema<br/>reporting views]
        AUD[etl schema<br/>job_run, step_log,<br/>data_quality_issue,<br/>dq_test_result]
    end

    PBI[Power BI<br/>Import mode]

    CRM -- "\copy (Talend: tFileInputDelimited)" --> STG
    CLM -- "\copy" --> STG
    PAS -- "COPY TO | COPY FROM (Talend: tDBInput -> tDBOutput)" --> STG
    STG --> VAL
    VAL -- "upsert valid rows" --> CORE
    VAL -- "ERROR / WARNING rows" --> AUD
    CORE --> RPT
    AUD --> RPT
    RPT --> PBI
```

## 2. Layers and responsibilities

| Layer | Schema | Contents | Why it exists |
|---|---|---|---|
| Staging | `stg` | Exact copy of source rows. CSV columns stored as `TEXT`. | Extraction never fails on bad data; the raw value is preserved for auditing and reprocessing; sources are read once and quickly. |
| Validation / transformation | `etl` views | Parsing, cleaning, lookups to warehouse keys, rule evaluation, de-duplication ranking. | All business rules in one inspectable place. `SELECT * FROM etl.v_claim_validated WHERE reject_reason IS NOT NULL` shows what will be rejected **before** loading. |
| Core / transformed | `dw` | Star schema with surrogate keys, PK/FK, CHECK constraints, indexes. | Single, clean, conformed version of the data. Constraints are a safety net behind the ETL rules. |
| Reporting | `rpt` | Views used by Power BI + SQL KPI views. | Stable contract between warehouse and report; KPIs computed in SQL are used to validate DAX. |
| Audit / monitoring | `etl` tables | Runs, per-step row counts, every data-quality issue with the raw record, quality-gate results. | Answers "how many rows came in, how many were loaded, rejected, why, and how long did it take". |

## 3. Data model (dw schema)

```mermaid
erDiagram
    dim_customer ||--o{ dim_policy : holds
    dim_product  ||--o{ dim_policy : "sold as"
    dim_policy   ||--o{ fact_claim : "claimed on"
    dim_policy   ||--o{ fact_premium_payment : "paid for"
    dim_customer ||--o{ fact_claim : ""
    dim_product  ||--o{ fact_claim : ""
    dim_customer ||--o{ fact_premium_payment : ""
    dim_product  ||--o{ fact_premium_payment : ""
    dim_date     ||--o{ fact_claim : "claim / reported date"
    dim_date     ||--o{ fact_premium_payment : "payment date"

    dim_customer { int customer_key PK
                   varchar customer_id UK
                   varchar region
                   varchar segment
                   date birth_date }
    dim_product  { int product_key PK
                   varchar product_code UK
                   varchar line_of_business }
    dim_policy   { int policy_key PK
                   varchar policy_number UK
                   int customer_key FK
                   int product_key FK
                   date start_date
                   date end_date
                   varchar status }
    dim_date     { int date_key PK
                   date full_date UK }
    fact_claim   { bigint claim_key PK
                   varchar claim_id UK
                   int policy_key FK
                   int claim_date_key FK
                   numeric claimed_amount
                   numeric paid_amount
                   varchar claim_status }
    fact_premium_payment { bigint premium_payment_key PK
                   int source_payment_id UK
                   int policy_key FK
                   int payment_date_key FK
                   numeric amount }
```

**Grain** (the most important modelling decision):
- `fact_claim`: one row per claim, holding its latest known state (status, paid amount).
- `fact_premium_payment`: one row per premium payment received.
- `dim_policy`: one row per policy; used as a dimension in SQL and as a third fact table in Power BI (see the Power BI guide).

Facts carry `customer_key` and `product_key` in addition to `policy_key` (denormalised) so Power BI can use a pure star schema. Test `claim_keys_consistent_with_policy` guarantees these copies never disagree with `dim_policy`.

## 4. Pipeline execution sequence

```mermaid
sequenceDiagram
    participant O as run_pipeline.sh (Talend job)
    participant S as src_policy_admin
    participant W as insurance_dw
    O->>W: etl.start_run() -> run_id
    O->>W: TRUNCATE stg.*
    O->>W: \copy CSV files -> stg (log_step)
    O->>S: COPY (SELECT ...) TO STDOUT
    S-->>O: rows (CSV stream)
    O->>W: COPY FROM STDIN -> stg (log_step)
    loop dims, then facts
        O->>W: CALL etl.load_xxx(run_id)
        Note over W: log rejects + warnings,<br/>upsert, log_step
    end
    O->>W: CALL etl.run_dq_tests(run_id)
    alt blocking test failed or any step error
        O->>W: etl.finish_run(run_id, 'FAILED', message)
    else
        O->>W: etl.finish_run(run_id, 'SUCCESS')
    end
```

## 5. Deployment view

| Environment | Database | Data | Who runs the pipeline |
|---|---|---|---|
| DEV | local PostgreSQL / Docker | generated sample data | developer, manually |
| UAT | shared PostgreSQL | anonymised copy of production | scheduler; business users validate the dashboard against source reports |
| PROD | production PostgreSQL | real data | scheduler (Talend Management Console / cron), alert on non-zero exit |

The same SQL scripts are deployed to every environment; only `.env` values differ (configuration separated from code).
