# Functional & Technical Specification

## 1. Business problem

A (fictional) insurance company keeps customers in a CRM, policies and premium payments in a Policy Administration System, and claims in a separate Claims system. Management cannot answer basic questions reliably – *which products lose money, where claims come from, how claim volumes evolve* – because the data lives in three systems with different formats, duplicates and inconsistent quality.

## 2. Business requirements

| ID | Requirement |
|---|---|
| BR-1 | One dashboard showing policies, claims, premium revenue, payouts and loss ratio. |
| BR-2 | KPIs can be sliced by product, line of business, region, customer segment and time. |
| BR-3 | Numbers must be traceable: for any run it must be possible to see how many records were received, loaded and rejected, and why. |
| BR-4 | Bad source data must not silently enter the reports. |
| BR-5 | The data is refreshed by a repeatable, automated daily process. |

## 3. Functional requirements

| ID | Requirement | Implemented in |
|---|---|---|
| FR-1 | Extract customers (CSV), claims (CSV), products/policies/premiums (PostgreSQL). | `etl/run_pipeline.sh` |
| FR-2 | Keep raw extracted data in a staging layer. | `sql/02_staging_tables.sql` |
| FR-3 | Parse dates in the formats `YYYY-MM-DD`, `DD/MM/YYYY`, `DD.MM.YYYY`. | `etl.try_parse_date` |
| FR-4 | Standardise names (trim, collapse spaces, capitalise). | `etl.clean_name` |
| FR-5 | Keep the most recent version of duplicated customers (by `last_updated`). | `etl.v_customer_validated.dup_rank` |
| FR-6 | Drop exact duplicate claim rows. | `etl.v_claim_validated.dup_rank` |
| FR-7 | Reject records that violate blocking rules; load records with non-blocking issues after correction; log both. | section 5, `sql/06_load_procedures.sql` |
| FR-8 | Loads are idempotent (re-running does not duplicate or change data). | `ON CONFLICT ... WHERE IS DISTINCT FROM` |
| FR-9 | Record every run and step with row counts and duration. | `etl.job_run`, `etl.step_log` |
| FR-10 | Fail the run if the rejection rate of any step exceeds a configurable threshold or reconciliation fails. | `etl.run_dq_tests` |
| FR-11 | Provide reporting views and DAX measures for the required KPIs. | `sql/07_reporting_views.sql`, `powerbi/` |

## 4. Non-functional requirements

| Category | Requirement |
|---|---|
| Reliability | A failed run leaves a `FAILED` record with the error message; the script exits non-zero so a scheduler can alert. |
| Traceability | Every rejected row is stored with its original raw values (`raw_record` JSONB). |
| Maintainability | Business rules live in one view per entity; SQL objects are versioned in Git and redeployable (`CREATE OR REPLACE`, `IF NOT EXISTS`). |
| Security | No credentials in the repository; `.env` is git-ignored; report uses a read-only account. |
| Performance | Set-based SQL (no row-by-row loops); indexes on all fact foreign keys; full sample run ≈ 1.5 s locally. |
| Portability | PostgreSQL 14+; Bash (Linux, macOS, Git Bash / WSL on Windows); Docker Compose provided. |

## 5. Data-quality rule catalogue

**Blocking (ERROR → row rejected)**

| Entity | Rule | Condition |
|---|---|---|
| all | MISSING_BUSINESS_KEY | business key empty |
| customer | MISSING_NAME | first or last name empty after cleaning |
| policy | ORPHAN_CUSTOMER | customer_id not in `dim_customer` |
| policy | UNKNOWN_PRODUCT | product_code not in `dim_product` |
| policy | INVALID_POLICY_PERIOD | end_date ≤ start_date |
| premium | ORPHAN_POLICY / INVALID_AMOUNT / DATE_OUT_OF_RANGE | lookup fails / amount ≤ 0 / date not in calendar |
| claim | INVALID_CLAIM_DATE | date unparseable |
| claim | ORPHAN_POLICY | policy not in `dim_policy` |
| claim | CLAIM_OUTSIDE_COVERAGE | claim date outside policy period |
| claim | INVALID_CLAIMED_AMOUNT | missing, non-numeric or ≤ 0 |
| claim | PAID_EXCEEDS_CLAIMED | paid > claimed |
| claim | INVALID_STATUS | not OPEN / PAID / REJECTED |

**Non-blocking (WARNING → loaded with correction)**

| Entity | Rule | Correction |
|---|---|---|
| customer | INVALID_BIRTH_DATE | set NULL (unparseable, before 1900 or in the future) |
| customer | MISSING_EMAIL / INVALID_EMAIL | set NULL |
| customer | MISSING_REGION / INVALID_SEGMENT | set 'Unknown' |
| customer | DUPLICATE_SUPERSEDED | older version dropped |
| claim | DUPLICATE_RECORD | duplicate row dropped |

The split is a **business decision**: a customer without a birth date is still a valid customer; a claim without an amount cannot be reported on.

## 6. Results on the sample data (actual run)

| Step | Read | Inserted | Duplicates | Rejected |
|---|---|---|---|---|
| customers | 1,026 | 1,000 | 25 | 1 |
| products | 5 | 5 | 0 | 0 |
| policies | 1,567 | 1,567 | 0 | 0 |
| premium payments | 3,216 | 3,216 | 0 | 0 |
| claims | 369 | 349 | 7 | 13 |

The 13 rejected claims correspond exactly to the 12 defects injected by the generator plus one duplicate of an already invalid row. A second run on the same data inserts 0 and updates 0 rows.

## 7. Security considerations

- Credentials only in `.env` (git-ignored) / environment variables; `.env.example` documents the variables.
- Recommended roles (not created by the scripts, to keep setup simple):
  - `etl_writer`: `USAGE` on `stg, dw, etl`, DML on those schemas, `EXECUTE` on procedures.
  - `report_reader`: `USAGE` + `SELECT` on `rpt` only – Power BI never sees staging or raw rejected records.
- `etl.data_quality_issue.raw_record` may contain personal data (names, emails, birth dates): restrict access and define a retention period (GDPR data minimisation).
- Customer names and emails are not needed for aggregate KPIs; `rpt.dim_customer` exposes the name only for the drill-through page and does not expose email or birth date.
- The Bash script builds SQL with values it controls (run id, fixed table names); no user input is concatenated into SQL.

## 8. Performance considerations

- `COPY` is used for bulk loading instead of row-by-row `INSERT`.
- Validation and loading are set-based (`INSERT ... SELECT`), which scales far better than per-row procedural code.
- Indexes on fact foreign keys and date keys support the joins used by reporting views; business keys are indexed by their `UNIQUE` constraints, which also power `ON CONFLICT`.
- Upserts update only changed rows, reducing write volume and table bloat.
- At larger volumes: incremental extraction (watermark on `updated_at`), partitioning facts by date, materialized views for heavy KPIs, `ANALYZE` after load.

## 9. Known limitations (documented on purpose)

- **Full extract every run.** Fine for this volume; incremental loads are implemented in the Multi-Source ETL project.
- **Each load step commits separately.** If `load_fact_claim` fails after dimensions were loaded, dimensions stay updated. This is safe because loads are idempotent (the next run completes the job), but facts can be briefly behind dimensions. Alternative: run all load steps in one transaction.
- **SCD Type 1** on customers: a region change overwrites history, so past claims move to the new region. SCD Type 2 would preserve history at the cost of a more complex model.
- **Loss ratio on a cash basis** (paid claims / collected premium). An actuarial loss ratio uses earned premium and incurred losses (paid + reserves).
- Deleted source records are not detected (no soft-delete handling).

## 10. Future improvements

1. Incremental extraction using `updated_at` watermarks stored in an `etl.watermark` table.
2. SCD Type 2 for `dim_customer` (`valid_from`, `valid_to`, `is_current`).
3. Earned premium calculation (pro-rata by days of coverage) for a true loss ratio.
4. Role-based access scripts and row-level security in Power BI (e.g. regional managers see only their region).
5. Extend CI (`.github/workflows/ci.yml`, which already runs setup, pipeline and all tests on every push) with SQL linting (e.g. SQLFluff) and deployment to a UAT database.
