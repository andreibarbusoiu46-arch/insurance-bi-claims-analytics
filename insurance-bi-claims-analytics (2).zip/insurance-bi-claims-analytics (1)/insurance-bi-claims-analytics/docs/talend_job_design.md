# Talend Job Design

## Status and honesty note

Talend Open Studio (the free edition) was retired by Qlik in early 2024 and is no longer officially distributed. For that reason this repository contains a **runnable reference implementation** of the job in SQL + Bash (`etl/run_pipeline.sh`), and this document specifies how the same job is built in Talend Studio. The warehouse side (staging tables, validation views, load procedures, audit tables) is identical in both implementations; only the orchestration and extraction layer changes.

If you have Talend Studio available (an archived Open Studio 8.x installation or a Talend Cloud trial), build the job below and export it to `talend/`. Do not claim a Talend implementation in your CV unless you built it.

## Job structure

```
J_INSURANCE_BI_MASTER                          (parent job, context: DEV / UAT / PROD)
 ├── tPrejob → tDBConnection (DW)  → tDBConnection (SRC)
 ├── tDBRow  "SELECT etl.start_run('insurance_bi_daily_load')"  → globalMap run_id
 ├── tRunJob J_EXTRACT_CSV            (OnSubjobOk)
 ├── tRunJob J_EXTRACT_POLICY_ADMIN   (OnSubjobOk)
 ├── tRunJob J_TRANSFORM_LOAD         (OnSubjobOk)
 ├── tDBRow  "CALL etl.run_dq_tests(run_id, context.max_reject_pct)"
 ├── tDBRow  "CALL etl.finish_run(run_id, 'SUCCESS')"
 ├── tLogCatcher → tMap → tDBRow "CALL etl.finish_run(run_id,'FAILED', message)"
 └── tPostjob → tDBClose (both connections)
```

### J_EXTRACT_CSV
| Component | Configuration |
|---|---|
| tDBRow | `TRUNCATE stg.crm_customers, stg.claims ... RESTART IDENTITY` |
| tFileExist → (If false) tDie | fails the job with a clear message if a source file is missing |
| tFileInputDelimited | `context.src_dir + "/crm_customers.csv"`, separator `;`, header 1, **all columns String** |
| tFlowMeter | counts rows for the step log |
| tDBOutput | `stg.crm_customers`, action *Insert*, batch size 1000 |
| tDBRow | `CALL etl.log_step(run_id, 'extract_crm_customers', start_ts, rows)` |
| (repeat for `claims_export.csv`, separator `,`) | |

All CSV columns are read as String on purpose: type conversion happens later in validation, so a malformed value produces a logged, explainable reject instead of a crashed job.

### J_EXTRACT_POLICY_ADMIN
| Component | Configuration |
|---|---|
| tDBInput (SRC connection) | `SELECT ... FROM policies` (same queries as `run_pipeline.sh`) |
| tDBOutput (DW connection) | `stg.policies`, *Insert* |
| (repeat for products, premium_payments) | |

This is the "multiple SQL databases" part: two connections, extraction from one database and loading into another.

### J_TRANSFORM_LOAD
Transformations are **pushed down to the database** (ELT-style) and invoked with `tDBSP` / `tDBRow`:
```
tDBRow CALL etl.load_dim_product(run_id)
  → tDBRow CALL etl.load_dim_customer(run_id)
  → tDBRow CALL etl.load_dim_policy(run_id)
  → tDBRow CALL etl.load_fact_premium_payment(run_id)
  → tDBRow CALL etl.load_fact_claim(run_id)
```

**Alternative (in-Talend transformation)**: `tDBInput(stg) → tMap (parse dates with TalendDate.parseDate in try/catch routines, lookups to dim tables as lookup flows, reject output enabled) → tUniqRow (dedup) → tDBOutput (Insert or update)` with the tMap reject flow → `tDBOutput etl.data_quality_issue`.
- Better when: sources and target are different database engines, transformations need Java logic, or the team standardises on visual mappings.
- Worse here because: data is already in the target database, set-based SQL is faster than row-by-row processing, and the rules can be tested with plain SQL.

## Context variables (one context group per environment)

| Variable | DEV | UAT | PROD |
|---|---|---|---|
| dw_host / dw_port / dw_database | localhost / 5432 / insurance_dw | uat-db / 5432 / insurance_dw | prod-db / ... |
| dw_user / dw_password | from context file, password type | from vault | from vault |
| src_dir | ./data/sources | /mnt/uat/landing | /mnt/prod/landing |
| max_reject_pct | 5 | 5 | 2 |

Passwords are never stored in the job itself: they are loaded at runtime (implicit context load from a protected file or a secrets manager).

## Error handling

| Situation | Behaviour |
|---|---|
| Source file missing | tFileExist → tDie → tLogCatcher → run FAILED, message stored |
| Bad value in a row | Not an error: row rejected by a validation rule and stored in `etl.data_quality_issue` with the raw record |
| SQL error in a load step | Procedure transaction rolls back; tLogCatcher marks run FAILED |
| Quality gate fails | `run_dq_tests` raises → run FAILED; dashboard refresh should be skipped |
