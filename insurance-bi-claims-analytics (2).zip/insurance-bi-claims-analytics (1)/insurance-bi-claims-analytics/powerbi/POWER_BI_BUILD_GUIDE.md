# Power BI Dashboard – Build Guide

The `.pbix` file is binary and is built manually in Power BI Desktop (Windows). This guide makes the build reproducible and lists the SQL-computed totals the dashboard must match.

## 1. Connect

1. Run the pipeline first (`./etl/run_pipeline.sh`) so the warehouse is populated.
2. Power BI Desktop → **Get Data → PostgreSQL database** → server `localhost:5432`, database `insurance_dw`, mode **Import**.
3. Select only the `rpt` views: `dim_date`, `dim_customer`, `dim_product`, `dim_policy`, `fact_claim`, `fact_premium_payment`, `v_etl_run_summary`, `v_dq_issue_summary`.
4. Rename them in Power Query: `Date`, `Customer`, `Product`, `Policies`, `Claims`, `Premiums`, `ETL Runs`, `DQ Issues`.
5. Use a dedicated read-only database user for the report (see `docs/technical_specification.md`, Security).

**Why Import and not DirectQuery?** Data changes once per day (batch ETL) and the volume is small, so Import gives the fastest visuals and full DAX support. DirectQuery would be the better choice for near-real-time data or tables too large to import; the trade-off is slower visuals and restricted DAX.

## 2. Model (star schema, 3 fact tables sharing conformed dimensions)

| From (many) | To (one) | Active | Notes |
|---|---|---|---|
| Claims[claim_date_key] | Date[date_key] | yes | claims analysed by occurrence date |
| Claims[reported_date_key] | Date[date_key] | **no** | activated in DAX with `USERELATIONSHIP` |
| Claims[customer_key] | Customer[customer_key] | yes | |
| Claims[product_key] | Product[product_key] | yes | |
| Premiums[payment_date_key] | Date[date_key] | yes | |
| Premiums[customer_key] | Customer[customer_key] | yes | |
| Premiums[product_key] | Product[product_key] | yes | |
| Policies[start_date_key] | Date[date_key] | yes | |
| Policies[customer_key] | Customer[customer_key] | yes | |
| Policies[product_key] | Product[product_key] | yes | |

- All relationships: **many-to-one, single cross-filter direction** (dimension filters fact).
- `Policies` is used as a third fact table. There is intentionally **no** relationship between `Claims` and `Policies`: it would create two filter paths from `Customer` to `Claims` (ambiguous model). Customer and product keys are already on every fact.
- Mark `Date` as date table (`full_date`). Hide all `*_key` columns from report view.
- Create an empty table `_Measures` and paste the measures from `measures.dax`.
- Hierarchies: `Date` → Year › Quarter › Month; `Product` → line_of_business › product_name; `Customer` → region › segment.

## 3. Report pages

**Page 1 – Executive Overview**
- KPI cards: Total Policies, Policies In Force, Total Claims, Revenue, Payouts, Loss Ratio (colour via `Loss Ratio Color`), Claim Frequency, Claim Severity.
- Line chart: Revenue and Payouts by Year-Month (+ Revenue YTD on secondary axis).
- Clustered bar: Loss Ratio by Product (sorted desc).
- Slicers: Year, Line of Business, Region, Segment.

**Page 2 – Claims Analysis**
- Matrix with drill-down: Line of Business › Product › Claim Type → Total Claims, Claimed Amount, Payouts, Claim Severity.
- Map or bar: Claims by Region; Donut: Claims by Segment; Column: Claims by Claim Status.
- Line: Total Claims vs Claims by Reported Date by month (shows reporting lag effect).
- Card: Avg Reporting Lag (days), Open Claims, Claim Rejection Rate.
- Drill-through page "Customer detail" (drill-through field: Customer[customer_id]).

**Page 3 – Data Quality & ETL Monitoring**
- Table from `ETL Runs`: run_id, status, duration_sec, rows_read, rows_inserted, rows_rejected.
- Bar: `DQ Issues` issue_count by rule_code, legend = severity, filtered to the latest run.
- This page lets a business user see whether the numbers on pages 1–2 can be trusted.

## 4. Validation – dashboard must match SQL

Values below come from the provided sample data (`python scripts/generate_source_data.py`, seed 42) after one pipeline run, with **no slicers applied**:

| Measure | Expected | SQL check |
|---|---|---|
| Total Policies | 1,567 | `SELECT count(*) FROM rpt.dim_policy` |
| Total Claims | 349 | `SELECT count(*) FROM rpt.fact_claim` |
| Revenue | 2,242,212.61 | `SELECT sum(amount) FROM rpt.fact_premium_payment` |
| Payouts | 1,326,917.19 | `SELECT sum(paid_amount) FROM rpt.fact_claim` |
| Claim Severity | 6,727.24 | claimed 2,347,806.86 / 349 |
| Loss Ratio | 0.5918 | payouts / revenue |
| Policies In Force, year 2024 | 1,565 | see `rpt.v_kpi_product_year` |

Per product/year values are in `rpt.v_kpi_product_year`; a mismatch indicates a model or DAX error (typically a wrong relationship direction or a missing `REMOVEFILTERS`).

## 5. Screenshots

After building, export screenshots of each page to `docs/img/` and reference them in the README. Do not commit screenshots of a dashboard you did not build yourself.
