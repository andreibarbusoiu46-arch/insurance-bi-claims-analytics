"""
Generates realistic, deterministic source data for the Insurance BI project.

Two source systems are simulated:
  1. CSV exports   -> data/sources/crm_customers.csv   (CRM system)
                   -> data/sources/claims_export.csv   (Claims system)
  2. A PostgreSQL "Policy Administration" database -> data/sources/policy_admin_seed.sql
     (products, policies, premium_payments)

Data-quality problems are injected ON PURPOSE so the ETL has something real to do:
  - duplicate customer rows (same customer exported twice, newer version wins)
  - missing emails / regions / segments
  - birth dates in 3 different formats + some invalid dates
  - claims pointing to non-existent policies (orphans)
  - negative or missing claim amounts, paid > claimed
  - claim dates before policy start
  - duplicate claim rows

Run:  python scripts/generate_source_data.py
Uses only the Python standard library. Seeded -> same output every run.
"""
import csv
import random
from datetime import date, timedelta
from pathlib import Path

SEED = 42
N_CUSTOMERS = 1000
OUT = Path(__file__).resolve().parent.parent / "data" / "sources"

REGIONS = ["Bucuresti-Ilfov", "Nord-Est", "Sud-Est", "Sud-Muntenia",
           "Sud-Vest Oltenia", "Vest", "Nord-Vest", "Centru"]
SEGMENTS = ["Retail", "Premium", "SME"]
FIRST = ["Andrei", "Maria", "Ioana", "Mihai", "Elena", "Alexandru", "Ana", "Cristian",
         "Diana", "Stefan", "Raluca", "Bogdan", "Irina", "Vlad", "Oana", "George"]
LAST = ["Popescu", "Ionescu", "Popa", "Stan", "Dumitru", "Stoica", "Gheorghe",
        "Matei", "Ciobanu", "Rusu", "Munteanu", "Florea", "Marin", "Tudor"]

PRODUCTS = [
    # code, name, line_of_business, base_annual_premium, claim_prob, avg_claim
    ("AUTO-RCA", "Motor Third Party Liability", "Motor", 1400, 0.22, 6500),
    ("AUTO-CASCO", "Motor Own Damage (CASCO)", "Motor", 3200, 0.30, 7800),
    ("HOME-STD", "Home Insurance Standard", "Property", 450, 0.08, 9000),
    ("HEALTH-PLUS", "Private Health Plus", "Health", 2400, 0.35, 2600),
    ("TRAVEL-EU", "Travel Insurance Europe", "Travel", 180, 0.10, 1900),
]
CLAIM_TYPES = {"Motor": ["Collision", "Theft", "Glass"],
               "Property": ["Fire", "Water Damage", "Burglary"],
               "Health": ["Hospitalization", "Outpatient"],
               "Travel": ["Medical Abroad", "Lost Luggage"]}

rnd = random.Random(SEED)


def rand_date(start: date, end: date) -> date:
    return start + timedelta(days=rnd.randint(0, (end - start).days))


def fmt_birth(d: date) -> str:
    """Mixed date formats, like real exports from different CRM versions."""
    r = rnd.random()
    if r < 0.6:
        return d.isoformat()                 # 1985-03-21
    if r < 0.85:
        return d.strftime("%d/%m/%Y")        # 21/03/1985
    if r < 0.97:
        return d.strftime("%d.%m.%Y")        # 21.03.1985
    return rnd.choice(["31/02/1990", "not available", "1899-01-01"])  # invalid


def sql_str(v):
    return "NULL" if v is None else "'" + str(v).replace("'", "''") + "'"


def main():
    OUT.mkdir(parents=True, exist_ok=True)

    # ---------------- CRM customers (CSV source #1) ----------------
    customers = []
    for i in range(1, N_CUSTOMERS + 1):
        fn, ln = rnd.choice(FIRST), rnd.choice(LAST)
        customers.append({
            "customer_id": f"C{i:05d}",
            "first_name": fn,
            "last_name": ln,
            "email": None if rnd.random() < 0.05 else f"{fn}.{ln}{i}@example.com".lower(),
            "birth_date": fmt_birth(rand_date(date(1950, 1, 1), date(2004, 12, 31))),
            "region": None if rnd.random() < 0.04 else rnd.choice(REGIONS),
            "segment": None if rnd.random() < 0.03 else rnd.choices(SEGMENTS, [70, 20, 10])[0],
            "last_updated": rand_date(date(2023, 1, 1), date(2024, 6, 30)).isoformat(),
        })
    rows = list(customers)
    # duplicates: same customer exported again with a newer timestamp and changed region
    for c in rnd.sample(customers, 25):
        d = dict(c)
        d["last_updated"] = "2024-12-15"
        d["region"] = rnd.choice(REGIONS)
        d["first_name"] = "  " + d["first_name"].upper() + " "   # dirty whitespace/casing
        rows.append(d)
    # rows with a missing business key -> must be rejected
    rows.append({**customers[0], "customer_id": "", "last_updated": "2024-01-01"})
    rnd.shuffle(rows)
    with open(OUT / "crm_customers.csv", "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=list(customers[0].keys()), delimiter=";", lineterminator="\n")
        w.writeheader()
        w.writerows(rows)

    # ---------------- Policy admin DB (source #2) ----------------
    policies, premiums = [], []
    pid = 0
    for c in customers:
        for _ in range(rnd.choices([1, 2, 3], [55, 35, 10])[0]):
            pid += 1
            code, _, lob, base, *_ = rnd.choice(PRODUCTS)
            start = rand_date(date(2023, 1, 1), date(2024, 12, 1))
            end = start + timedelta(days=364)
            status = "CANCELLED" if rnd.random() < 0.06 else ("EXPIRED" if end < date(2025, 1, 1) else "ACTIVE")
            premium = round(base * rnd.uniform(0.8, 1.3), 2)
            freq = rnd.choice(["ANNUAL", "QUARTERLY"])
            policies.append((f"POL-{pid:06d}", c["customer_id"], code, start, end, status, premium, freq))
            n_inst = 1 if freq == "ANNUAL" else 4
            months_paid = 1 if status == "CANCELLED" else n_inst
            for k in range(months_paid):
                pay_date = start + timedelta(days=91 * k)
                if pay_date > date(2024, 12, 31):
                    break
                premiums.append((f"POL-{pid:06d}", pay_date, round(premium / n_inst, 2), rnd.choice(["CARD", "BANK_TRANSFER", "CASH"])))

    with open(OUT / "policy_admin_seed.sql", "w", encoding="utf-8") as f:
        f.write("-- Simulated Policy Administration System (separate database: src_policy_admin)\n")
        f.write("DROP TABLE IF EXISTS premium_payments, policies, products;\n")
        f.write("""CREATE TABLE products (
    product_code VARCHAR(20) PRIMARY KEY,
    product_name VARCHAR(100) NOT NULL,
    line_of_business VARCHAR(30) NOT NULL,
    base_annual_premium NUMERIC(12,2) NOT NULL);
CREATE TABLE policies (
    policy_number VARCHAR(20) PRIMARY KEY,
    customer_id VARCHAR(10) NOT NULL,          -- lives in CRM, no FK possible across systems
    product_code VARCHAR(20) NOT NULL REFERENCES products(product_code),
    start_date DATE NOT NULL,
    end_date DATE NOT NULL,
    status VARCHAR(15) NOT NULL,
    annual_premium NUMERIC(12,2) NOT NULL,
    payment_frequency VARCHAR(15) NOT NULL,
    updated_at TIMESTAMP NOT NULL DEFAULT now());
CREATE TABLE premium_payments (
    payment_id SERIAL PRIMARY KEY,
    policy_number VARCHAR(20) NOT NULL REFERENCES policies(policy_number),
    payment_date DATE NOT NULL,
    amount NUMERIC(12,2) NOT NULL,
    payment_method VARCHAR(20) NOT NULL);
""")
        for p in PRODUCTS:
            f.write(f"INSERT INTO products VALUES ({sql_str(p[0])},{sql_str(p[1])},{sql_str(p[2])},{p[3]});\n")
        f.write("INSERT INTO policies (policy_number,customer_id,product_code,start_date,end_date,status,annual_premium,payment_frequency) VALUES\n")
        f.write(",\n".join(f"({sql_str(p[0])},{sql_str(p[1])},{sql_str(p[2])},'{p[3]}','{p[4]}',{sql_str(p[5])},{p[6]},{sql_str(p[7])})" for p in policies) + ";\n")
        f.write("INSERT INTO premium_payments (policy_number,payment_date,amount,payment_method) VALUES\n")
        f.write(",\n".join(f"({sql_str(p[0])},'{p[1]}',{p[2]},{sql_str(p[3])})" for p in premiums) + ";\n")

    # ---------------- Claims export (CSV source #3) ----------------
    prod_by_code = {p[0]: p for p in PRODUCTS}
    claims = []
    cid = 0
    for pol in policies:
        _, _, lob, _, prob, avg = prod_by_code[pol[2]]
        if rnd.random() < prob:
            cid += 1
            cdate = rand_date(pol[3], min(pol[4], date(2024, 12, 31)))
            claimed = round(rnd.lognormvariate(0, 0.8) * avg, 2)
            status = rnd.choices(["PAID", "REJECTED", "OPEN"], [70, 12, 18])[0]
            paid = round(claimed * rnd.uniform(0.6, 1.0), 2) if status == "PAID" else 0
            claims.append({
                "claim_id": f"CLM-{cid:06d}", "policy_number": pol[0],
                "claim_date": cdate.isoformat(),
                "reported_date": (cdate + timedelta(days=rnd.randint(0, 20))).isoformat(),
                "claim_type": rnd.choice(CLAIM_TYPES[lob]),
                "claimed_amount": f"{claimed:.2f}",
                "paid_amount": f"{paid:.2f}",
                "claim_status": status,
            })
    # inject problems
    bad = rnd.sample(claims, 12)
    for b in bad[0:3]:
        b["policy_number"] = "POL-999" + b["policy_number"][-3:]     # orphan policy
    for b in bad[3:5]:
        b["claimed_amount"] = "-" + b["claimed_amount"]              # negative amount
    for b in bad[5:7]:
        b["claimed_amount"] = ""                                     # missing amount
    for b in bad[7:9]:
        b["paid_amount"] = f"{float(b['claimed_amount'] or 0) * 1.5:.2f}"  # paid > claimed
    for b in bad[9:11]:
        b["claim_date"] = "2020-01-01"                               # before policy start
    bad[11]["claim_date"] = "2024-13-45"                             # invalid date
    claims += [dict(c) for c in rnd.sample(claims, 8)]                # exact duplicate rows
    rnd.shuffle(claims)
    with open(OUT / "claims_export.csv", "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=list(claims[0].keys()), delimiter=",", lineterminator="\n")
        w.writeheader()
        w.writerows(claims)

    print(f"customers csv rows: {len(rows)}  policies: {len(policies)}  "
          f"premium payments: {len(premiums)}  claims csv rows: {len(claims)}")


if __name__ == "__main__":
    main()
