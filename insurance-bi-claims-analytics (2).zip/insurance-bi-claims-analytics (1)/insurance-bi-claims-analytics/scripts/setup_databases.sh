#!/usr/bin/env bash
# Creates the two databases and deploys all DDL. Safe to re-run.
#   src_policy_admin : simulated Policy Administration System (a SOURCE)
#   insurance_dw     : the analytics warehouse (TARGET)
set -euo pipefail
cd "$(dirname "$0")/.."
[ -f .env ] && set -a && . ./.env && set +a
SRC_DB="${SRC_DB:-src_policy_admin}"
DW_DB="${DW_DB:-insurance_dw}"
PSQL="psql -X -q -v ON_ERROR_STOP=1"

for db in "$SRC_DB" "$DW_DB"; do
  if ! $PSQL -d postgres -tAc "SELECT 1 FROM pg_database WHERE datname='$db'" | grep -q 1; then
    echo "Creating database $db"
    $PSQL -d postgres -c "CREATE DATABASE $db"
  fi
done

echo "Loading source system data into $SRC_DB"
$PSQL -d "$SRC_DB" -f data/sources/policy_admin_seed.sql

echo "Deploying warehouse objects into $DW_DB"
for f in sql/01_schemas_and_audit.sql sql/02_staging_tables.sql sql/03_dw_tables.sql \
         sql/04_etl_functions.sql sql/05_validation_views.sql sql/06_load_procedures.sql \
         sql/07_reporting_views.sql sql/09_dq_tests.sql; do
  echo "  - $f"
  $PSQL -d "$DW_DB" -f "$f"
done
echo "Setup complete."
