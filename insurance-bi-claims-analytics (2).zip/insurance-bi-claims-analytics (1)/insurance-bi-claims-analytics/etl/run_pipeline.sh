#!/usr/bin/env bash
# =====================================================================
# Insurance BI daily load - executable reference implementation of the
# Talend job described in docs/talend_job_design.md.
#   EXTRACT   : 2 CSV files + 1 PostgreSQL source database -> stg.*
#   TRANSFORM : validation views + load procedures      -> dw.*
#   TEST      : data-quality gate                        -> etl.dq_test_result
# Every run is recorded in etl.job_run / etl.step_log. On any error the
# run is marked FAILED with the error text and the script exits non-zero
# (so a scheduler / CI can alert).
# =====================================================================
set -Eeuo pipefail   # -E: ERR trap also fires inside functions
cd "$(dirname "$0")/.."
[ -f .env ] && set -a && . ./.env && set +a
SRC_DB="${SRC_DB:-src_policy_admin}"
DW_DB="${DW_DB:-insurance_dw}"
MAX_REJECT_PCT="${MAX_REJECT_PCT:-5}"
SRC_DIR="${SRC_DIR:-data/sources}"
PSQL="psql -X -q -v ON_ERROR_STOP=1"

mkdir -p logs
RUN_ID=$($PSQL -d "$DW_DB" -tAc "SELECT etl.start_run('insurance_bi_daily_load')")
LOG="logs/run_${RUN_ID}.log"
echo "Run $RUN_ID started $(date '+%F %T')" | tee "$LOG"

now() { date '+%Y-%m-%d %H:%M:%S.%N%z'; }

fail() {
  local msg; msg=$(tail -n 3 "$LOG" | tr '\n' ' ' | sed "s/'/''/g")
  $PSQL -d "$DW_DB" -c "CALL etl.finish_run($RUN_ID, 'FAILED', '$msg')" || true
  echo "Run $RUN_ID FAILED - see $LOG" >&2
  exit 1
}
trap fail ERR

step() { echo "[$(date '+%T')] $1" | tee -a "$LOG"; }

# ---------------------------------------------------------------- EXTRACT
step "truncate staging"
$PSQL -d "$DW_DB" -c "TRUNCATE stg.crm_customers, stg.claims, stg.products, stg.policies, stg.premium_payments RESTART IDENTITY" 2>>"$LOG"

extract_csv() {            # $1 step name, $2 table(cols), $3 file, $4 delimiter
  local t0; t0=$(now)
  [ -f "$3" ] || { echo "Source file missing: $3" >>"$LOG"; return 1; }
  $PSQL -d "$DW_DB" -c "\copy $2 FROM '$3' WITH (FORMAT csv, HEADER true, DELIMITER '$4')" 2>>"$LOG"
  local tbl=${2%%(*}
  local n; n=$($PSQL -d "$DW_DB" -tAc "SELECT count(*) FROM $tbl" 2>>"$LOG")
  $PSQL -d "$DW_DB" -c "CALL etl.log_step($RUN_ID, '$1', '$t0', $n)" 2>>"$LOG"
}

extract_db() {             # $1 step name, $2 source query, $3 target table(cols)
  local t0; t0=$(now)
  $PSQL -d "$SRC_DB" -c "\copy ($2) TO pstdout WITH (FORMAT csv)" 2>>"$LOG" \
    | $PSQL -d "$DW_DB" -c "\copy $3 FROM pstdin WITH (FORMAT csv)" 2>>"$LOG"
  local tbl=${3%%(*}
  local n; n=$($PSQL -d "$DW_DB" -tAc "SELECT count(*) FROM $tbl" 2>>"$LOG")
  $PSQL -d "$DW_DB" -c "CALL etl.log_step($RUN_ID, '$1', '$t0', $n)" 2>>"$LOG"
}

step "extract CRM customers (CSV)"
extract_csv extract_crm_customers \
  "stg.crm_customers(customer_id,first_name,last_name,email,birth_date,region,segment,last_updated)" \
  "$SRC_DIR/crm_customers.csv" ";"

step "extract claims (CSV)"
extract_csv extract_claims \
  "stg.claims(claim_id,policy_number,claim_date,reported_date,claim_type,claimed_amount,paid_amount,claim_status)" \
  "$SRC_DIR/claims_export.csv" ","

step "extract products / policies / premiums (PostgreSQL: $SRC_DB)"
extract_db extract_products \
  "SELECT product_code, product_name, line_of_business, base_annual_premium FROM products" \
  "stg.products(product_code,product_name,line_of_business,base_annual_premium)"
extract_db extract_policies \
  "SELECT policy_number, customer_id, product_code, start_date, end_date, status, annual_premium, payment_frequency, updated_at FROM policies" \
  "stg.policies(policy_number,customer_id,product_code,start_date,end_date,status,annual_premium,payment_frequency,updated_at)"
extract_db extract_premium_payments \
  "SELECT payment_id, policy_number, payment_date, amount, payment_method FROM premium_payments" \
  "stg.premium_payments(payment_id,policy_number,payment_date,amount,payment_method)"

# ---------------------------------------------------------------- TRANSFORM + LOAD
# Order matters: dimensions before facts (facts look up dimension keys).
for proc in load_dim_product load_dim_customer load_dim_policy load_fact_premium_payment load_fact_claim; do
  step "$proc"
  $PSQL -d "$DW_DB" -c "CALL etl.$proc($RUN_ID)" 2>>"$LOG"
done

# ---------------------------------------------------------------- QUALITY GATE
step "data quality tests"
$PSQL -d "$DW_DB" -c "CALL etl.run_dq_tests($RUN_ID, $MAX_REJECT_PCT)" 2>>"$LOG"

$PSQL -d "$DW_DB" -c "CALL etl.finish_run($RUN_ID, 'SUCCESS')" 2>>"$LOG"
trap - ERR

# ---------------------------------------------------------------- REPORT
$PSQL -d "$DW_DB" -P footer=off <<SQL | tee -a "$LOG"
\echo '\n=== Step log ==='
SELECT step_name, rows_read AS read, rows_inserted AS ins, rows_updated AS upd,
       rows_unchanged AS unch, rows_duplicate AS dup, rows_rejected AS rej, duration_ms AS ms
FROM etl.step_log WHERE run_id = $RUN_ID ORDER BY step_log_id;
\echo '\n=== Data quality issues ==='
SELECT entity, rule_code, severity, issue_count FROM rpt.v_dq_issue_summary
WHERE run_id = $RUN_ID ORDER BY severity, entity, issue_count DESC;
\echo '\n=== Quality gate ==='
SELECT test_name, blocking, failed_rows, passed FROM etl.dq_test_result WHERE run_id = $RUN_ID;
\echo '\n=== Run summary ==='
SELECT run_id, status, duration_sec, rows_read, rows_inserted, rows_updated,
       rows_unchanged, rows_duplicate, rows_rejected FROM rpt.v_etl_run_summary WHERE run_id = $RUN_ID;
SQL
