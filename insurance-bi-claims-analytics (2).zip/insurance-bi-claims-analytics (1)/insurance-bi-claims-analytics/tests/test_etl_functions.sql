-- Unit tests for ETL helper functions. Each assertion raises on failure.
-- Run: psql -d insurance_dw -v ON_ERROR_STOP=1 -f tests/test_etl_functions.sql
DO $$
DECLARE
    r RECORD;
    failures INT := 0;
BEGIN
    FOR r IN
        SELECT * FROM (VALUES
            -- test name,                      actual,                                         expected
            ('iso date',             etl.try_parse_date('1985-03-21')::TEXT,        '1985-03-21'),
            ('slash date dd/mm',     etl.try_parse_date('21/03/1985')::TEXT,        '1985-03-21'),
            ('dotted date',          etl.try_parse_date('21.03.1985')::TEXT,        '1985-03-21'),
            ('trailing spaces',      etl.try_parse_date(' 1985-03-21 ')::TEXT,      '1985-03-21'),
            ('impossible date',      etl.try_parse_date('31/02/1990')::TEXT,        NULL),
            ('month 13',             etl.try_parse_date('2024-13-45')::TEXT,        NULL),
            ('free text',            etl.try_parse_date('not available')::TEXT,     NULL),
            ('empty string date',    etl.try_parse_date('')::TEXT,                  NULL),
            ('null date',            etl.try_parse_date(NULL)::TEXT,                NULL),
            ('plain number',         etl.try_parse_numeric('1234.50')::TEXT,        '1234.50'),
            ('comma decimal',        etl.try_parse_numeric('1234,50')::TEXT,        '1234.50'),
            ('negative number',      etl.try_parse_numeric('-10')::TEXT,            '-10'),
            ('non numeric',          etl.try_parse_numeric('abc')::TEXT,            NULL),
            ('empty numeric',        etl.try_parse_numeric('  ')::TEXT,             NULL),
            ('name trim + case',     etl.clean_name('  ANDREI '),                   'Andrei'),
            ('name inner spaces',    etl.clean_name('ana   maria'),                 'Ana Maria'),
            ('blank name -> null',   etl.clean_name('   '),                         NULL)
        ) AS t(test_name, actual, expected)
    LOOP
        IF r.actual IS DISTINCT FROM r.expected THEN
            failures := failures + 1;
            RAISE WARNING 'FAIL %: expected %, got %', r.test_name, r.expected, r.actual;
        ELSE
            RAISE NOTICE 'PASS %', r.test_name;
        END IF;
    END LOOP;
    IF failures > 0 THEN
        RAISE EXCEPTION '% unit test(s) failed', failures;
    END IF;
END;
$$;
