#!/usr/bin/env bash
# Test suite:
#   1. unit tests        - SQL helper functions in isolation
#   2. integration tests - the whole pipeline against real databases:
#        a) idempotency       : 2nd run on same data changes nothing
#        b) change detection  : a modified source row is UPDATED, not duplicated
#        c) failure handling  : missing source file -> run marked FAILED, DW untouched
# Requires: scripts/setup_databases.sh executed once.
set -uo pipefail
cd "$(dirname "$0")/.."
[ -f .env ] && set -a && . ./.env && set +a
DW_DB="${DW_DB:-insurance_dw}"
PSQL="psql -X -q -v ON_ERROR_STOP=1 -d $DW_DB"
PASS=0; FAIL=0
check() {  # $1 description, $2 actual, $3 expected
  if [ "$2" == "$3" ]; then echo "  PASS  $1"; PASS=$((PASS+1));
  else echo "  FAIL  $1 (expected '$3', got '$2')"; FAIL=$((FAIL+1)); fi
}
last_run_metric() { $PSQL -tAc "SELECT $1 FROM rpt.v_etl_run_summary ORDER BY run_id DESC LIMIT 1"; }

echo "== 1. Unit tests: ETL functions"
if $PSQL -f tests/test_etl_functions.sql 2>/tmp/unit.log; then check "helper functions" ok ok
else cat /tmp/unit.log; check "helper functions" failed ok; fi

echo "== 2a. Integration: first run + idempotent re-run"
./etl/run_pipeline.sh >/dev/null 2>&1; check "run succeeds" "$(last_run_metric status)" SUCCESS
./etl/run_pipeline.sh >/dev/null 2>&1; check "re-run succeeds" "$(last_run_metric status)" SUCCESS
check "re-run inserts 0 rows" "$(last_run_metric rows_inserted)" 0
check "re-run updates 0 rows" "$(last_run_metric rows_updated)" 0
check "no duplicate claims in DW" \
  "$($PSQL -tAc "SELECT count(*) - count(DISTINCT claim_id) FROM dw.fact_claim")" 0

echo "== 2b. Integration: change detection (claim OPEN -> PAID)"
TMP=$(mktemp -d); cp data/sources/*.csv "$TMP/"
CLAIM=$($PSQL -tAc "SELECT claim_id FROM dw.fact_claim WHERE claim_status='OPEN' ORDER BY claim_id LIMIT 1")
python3 - "$TMP/claims_export.csv" "$CLAIM" <<'PY'
import csv, sys
path, cid = sys.argv[1], sys.argv[2]
rows = list(csv.DictReader(open(path)))
for r in rows:
    if r["claim_id"] == cid:
        r["claim_status"] = "PAID"; r["paid_amount"] = f'{float(r["claimed_amount"]) * 0.5:.2f}'
w = csv.DictWriter(open(path, "w", newline=""), fieldnames=rows[0].keys(), lineterminator="\n")
w.writeheader(); w.writerows(rows)
PY
SRC_DIR="$TMP" ./etl/run_pipeline.sh >/dev/null 2>&1
check "exactly 1 row updated" "$(last_run_metric rows_updated)" 1
check "claim $CLAIM is now PAID" "$($PSQL -tAc "SELECT claim_status FROM dw.fact_claim WHERE claim_id='$CLAIM'")" PAID
./etl/run_pipeline.sh >/dev/null 2>&1   # restore original state

echo "== 2c. Integration: failure handling (missing source file)"
BEFORE=$($PSQL -tAc "SELECT count(*) FROM dw.fact_claim")
rm "$TMP/claims_export.csv"
SRC_DIR="$TMP" ./etl/run_pipeline.sh >/dev/null 2>&1; RC=$?
check "pipeline exits non-zero" "$([ $RC -ne 0 ] && echo yes || echo no)" yes
check "run marked FAILED" "$(last_run_metric status)" FAILED
check "error message recorded" \
  "$($PSQL -tAc "SELECT error_message LIKE '%missing%' FROM etl.job_run ORDER BY run_id DESC LIMIT 1")" t
check "warehouse unchanged after failure" "$($PSQL -tAc "SELECT count(*) FROM dw.fact_claim")" "$BEFORE"
rm -rf "$TMP"

echo; echo "Result: $PASS passed, $FAIL failed"
[ "$FAIL" -eq 0 ]
